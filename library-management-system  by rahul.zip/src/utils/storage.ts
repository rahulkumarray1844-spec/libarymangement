import { Book, Member, LoanTransaction, LateFeePayment, EmailReminder, SystemSettings } from '../types';
import { initialBooks, initialMembers, initialLoans, initialSettings } from '../data/initialData';

const STORAGE_KEYS = {
  BOOKS: 'lms_books_v1',
  MEMBERS: 'lms_members_v1',
  LOANS: 'lms_loans_v1',
  PAYMENTS: 'lms_payments_v1',
  EMAIL_LOGS: 'lms_email_logs_v1',
  SETTINGS: 'lms_settings_v1',
};

const initialPayments: LateFeePayment[] = [
  {
    id: 'pay-501',
    loanId: 'loan-306',
    memberId: 'm-205',
    memberName: 'Arthur Pendelton',
    bookTitle: 'To Kill a Mockingbird',
    amount: 1.50,
    paymentDate: new Date(Date.now() - 10 * 86400000).toISOString().split('T')[0],
    method: 'Cash',
    receiptNumber: 'REC-2024-0891',
    notes: 'Paid at front circulation desk upon return',
  }
];

const initialEmailLogs: EmailReminder[] = [
  {
    id: 'eml-601',
    loanId: 'loan-302',
    memberId: 'm-203',
    memberEmail: 'liam.chen@university.edu',
    memberName: 'Liam Chen',
    bookTitle: 'Design Patterns: Elements of Reusable Object-Oriented Software',
    dueDate: new Date(Date.now() - 8 * 86400000).toISOString().split('T')[0],
    daysOverdue: 8,
    fineAmount: 5.25,
    sentAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    status: 'Delivered',
    subject: 'URGENT: Overdue Library Item Notice - Design Patterns',
    bodySnippet: 'Dear Liam Chen, This is an automated notice that your loan is 8 days overdue. Accumulated late fee: $5.25...',
  },
  {
    id: 'eml-602',
    loanId: 'loan-303',
    memberId: 'm-204',
    memberEmail: 's.jenkins@research-institute.org',
    memberName: 'Sarah Jenkins',
    bookTitle: '1984',
    dueDate: new Date(Date.now() - 16 * 86400000).toISOString().split('T')[0],
    daysOverdue: 16,
    fineAmount: 11.25,
    sentAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    status: 'Delivered',
    subject: 'FINAL NOTICE: Overdue Library Item - 1984',
    bodySnippet: 'Dear Sarah Jenkins, Your checked-out book "1984" is currently 16 days overdue with an accrued late fee of $11.25...',
  }
];

export function getStoredBooks(): Book[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKS);
    if (!raw) return initialBooks;
    return JSON.parse(raw);
  } catch {
    return initialBooks;
  }
}

export function saveBooks(books: Book[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(books));
  } catch (err) {
    console.error('Failed to save books to localStorage', err);
  }
}

export function getStoredMembers(): Member[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    if (!raw) return initialMembers;
    return JSON.parse(raw);
  } catch {
    return initialMembers;
  }
}

export function saveMembers(members: Member[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  } catch (err) {
    console.error('Failed to save members to localStorage', err);
  }
}

export function getStoredLoans(): LoanTransaction[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LOANS);
    if (!raw) return initialLoans;
    return JSON.parse(raw);
  } catch {
    return initialLoans;
  }
}

export function saveLoans(loans: LoanTransaction[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(loans));
  } catch (err) {
    console.error('Failed to save loans to localStorage', err);
  }
}

export function getStoredPayments(): LateFeePayment[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    if (!raw) return initialPayments;
    return JSON.parse(raw);
  } catch {
    return initialPayments;
  }
}

export function savePayments(payments: LateFeePayment[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
  } catch (err) {
    console.error('Failed to save payments to localStorage', err);
  }
}

export function getStoredEmailLogs(): EmailReminder[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EMAIL_LOGS);
    if (!raw) return initialEmailLogs;
    return JSON.parse(raw);
  } catch {
    return initialEmailLogs;
  }
}

export function saveEmailLogs(logs: EmailReminder[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.EMAIL_LOGS, JSON.stringify(logs));
  } catch (err) {
    console.error('Failed to save email logs to localStorage', err);
  }
}

export function getStoredSettings(): SystemSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return initialSettings;
    return JSON.parse(raw);
  } catch {
    return initialSettings;
  }
}

export function saveSettings(settings: SystemSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings to localStorage', err);
  }
}

export function resetToSampleData(): void {
  localStorage.setItem(STORAGE_KEYS.BOOKS, JSON.stringify(initialBooks));
  localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(initialMembers));
  localStorage.setItem(STORAGE_KEYS.LOANS, JSON.stringify(initialLoans));
  localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(initialPayments));
  localStorage.setItem(STORAGE_KEYS.EMAIL_LOGS, JSON.stringify(initialEmailLogs));
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(initialSettings));
}
