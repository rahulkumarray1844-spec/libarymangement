import React, { useState } from 'react';
import {
  ArrowLeftRight,
  Clock,
  AlertTriangle,
  CheckCircle,
  RotateCw,
  ArrowDownLeft,
  Mail,
  Search,
  Calendar,
  User,
  BookOpen,
  DollarSign
} from 'lucide-react';
import { LoanTransaction, SystemSettings } from '../types';
import { calculateOverdueDays, computeLateFee, formatCurrency } from '../utils/lateFeeCalculator';

interface CirculationViewProps {
  loans: LoanTransaction[];
  settings: SystemSettings;
  searchQuery: string;
  onOpenIssueModal: () => void;
  onOpenReturnModal: (loan?: LoanTransaction) => void;
  onRenewLoan: (loanId: string) => void;
  onSendReminder: (loan: LoanTransaction) => void;
}

export const CirculationView: React.FC<CirculationViewProps> = ({
  loans,
  settings,
  searchQuery,
  onOpenIssueModal,
  onOpenReturnModal,
  onRenewLoan,
  onSendReminder,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'overdue' | 'returned'>('all');

  // Filter loans
  const filteredLoans = loans.filter(l => {
    const matchesSearch =
      !searchQuery ||
      l.bookTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.memberName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.memberCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.bookIsbn.includes(searchQuery);

    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'active' && (l.status === 'Active' || l.status === 'Overdue')) ||
      (statusFilter === 'overdue' && l.status === 'Overdue') ||
      (statusFilter === 'returned' && l.status === 'Returned');

    return matchesSearch && matchesStatus;
  });

  const activeLoans = loans.filter(l => l.status === 'Active' || l.status === 'Overdue');
  const overdueLoans = loans.filter(l => l.status === 'Overdue');
  const returnedLoans = loans.filter(l => l.status === 'Returned');
  const totalFinesAccrued = overdueLoans.reduce((sum, l) => {
    const f = computeLateFee(l.dueDate, settings);
    return sum + f.fee;
  }, 0);

  return (
    <div className="space-y-8">
      {/* Editorial Circulation Summary Cards */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-[#1A1A1A] pb-3 mb-6">
          <h2 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
            Circulation Ledger &amp; Lending Activity
          </h2>
          <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 sm:mt-0">
            Real-Time Audit Records
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x divide-[#1A1A1A]/20">
          <div className="pt-2 sm:pt-0 sm:pr-4">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {activeLoans.length.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Currently Circulating
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-red-700">
              {overdueLoans.length.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-red-700 mt-1 block font-semibold">
              Overdue Discrepancies
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {formatCurrency(totalFinesAccrued, settings.currencySymbol)}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Outstanding Late Fines
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:pl-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-emerald-800">
              {returnedLoans.length.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Returned into Stacks
            </span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-4 flex flex-wrap items-center justify-between gap-4">
        {/* Status Filters */}
        <div className="flex items-center border border-[#1A1A1A] p-0.5 text-xs font-sans uppercase tracking-wider">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 transition-all ${
              statusFilter === 'all' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            All Loans ({loans.length})
          </button>
          <button
            onClick={() => setStatusFilter('active')}
            className={`px-3 py-1.5 transition-all ${
              statusFilter === 'active' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            Active ({activeLoans.length})
          </button>
          <button
            onClick={() => setStatusFilter('overdue')}
            className={`px-3 py-1.5 transition-all flex items-center gap-1 ${
              statusFilter === 'overdue' ? 'bg-red-800 text-white font-bold' : 'text-red-700 hover:text-red-900 font-semibold'
            }`}
          >
            Overdue ({overdueLoans.length})
          </button>
          <button
            onClick={() => setStatusFilter('returned')}
            className={`px-3 py-1.5 transition-all ${
              statusFilter === 'returned' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            Returned ({returnedLoans.length})
          </button>
        </div>

        {/* Action button */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onOpenReturnModal()}
            className="px-4 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <ArrowDownLeft className="w-3.5 h-3.5" /> Return Book
          </button>
          <button
            onClick={onOpenIssueModal}
            className="px-4 py-2 bg-transparent hover:bg-[#1A1A1A] hover:text-[#FDFCF8] text-[#1A1A1A] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" /> Issue Book
          </button>
        </div>
      </div>

      {/* Loans Table Styled in Editorial Aesthetic */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] overflow-hidden">
        <div className="p-4 border-b border-[#1A1A1A] flex items-center justify-between">
          <h3 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
            Circulation Log Records
          </h3>
          <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/50">
            Showing {filteredLoans.length} Records
          </span>
        </div>

        {filteredLoans.length === 0 ? (
          <div className="p-12 text-center text-xs font-sans uppercase tracking-widest text-[#1A1A1A]/50">
            No circulation records match this criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="text-[10px] font-sans uppercase tracking-widest border-b border-[#1A1A1A] text-[#1A1A1A] bg-[#1A1A1A]/5">
                  <th className="px-6 py-3 font-normal">ID &amp; Title</th>
                  <th className="px-5 py-3 font-normal">Patron Borrower</th>
                  <th className="px-4 py-3 font-normal">Issue Date</th>
                  <th className="px-5 py-3 font-normal">Due Date &amp; Status</th>
                  <th className="px-4 py-3 font-normal">Fine Due</th>
                  <th className="px-6 py-3 text-right font-normal">Circulation Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]/15">
                {filteredLoans.map((loan) => {
                  const isOverdue = loan.status === 'Overdue';
                  const isReturned = loan.status === 'Returned';
                  const overdueDays = calculateOverdueDays(loan.dueDate, loan.returnDate);
                  const feeData = computeLateFee(loan.dueDate, settings, loan.returnDate);

                  return (
                    <tr
                      key={loan.id}
                      className={`hover:bg-[#1A1A1A]/5 transition-colors ${
                        isOverdue ? 'bg-red-50/40' : ''
                      }`}
                    >
                      {/* Book info */}
                      <td className="px-6 py-4 max-w-xs">
                        <div className="font-mono text-[10px] text-[#1A1A1A]/50 uppercase">
                          #{loan.id.slice(-6).toUpperCase()}
                        </div>
                        <div className="font-serif-display font-bold italic text-lg text-[#1A1A1A] leading-tight">
                          {loan.bookTitle}
                        </div>
                        <div className="font-mono text-[10px] text-[#1A1A1A]/60 mt-0.5">
                          ISBN: {loan.bookIsbn}
                        </div>
                      </td>

                      {/* Member info */}
                      <td className="px-5 py-4">
                        <div className="font-sans font-bold text-sm text-[#1A1A1A]">{loan.memberName}</div>
                        <div className="font-mono text-[10px] text-[#1A1A1A]/60">{loan.memberCode}</div>
                        <div className="text-[11px] text-[#1A1A1A]/50 font-sans">{loan.memberEmail}</div>
                      </td>

                      {/* Issue date */}
                      <td className="px-4 py-4 font-sans text-xs text-[#1A1A1A]">
                        {loan.issueDate}
                      </td>

                      {/* Due date & status */}
                      <td className="px-5 py-4">
                        <div className={`font-sans font-bold text-sm ${isOverdue ? 'text-red-700' : 'text-[#1A1A1A]'}`}>
                          {loan.dueDate}
                        </div>
                        <div className="mt-1">
                          {isReturned ? (
                            <span className="text-[9px] font-sans font-bold uppercase tracking-wider px-2 py-0.5 border border-emerald-800 text-emerald-900 bg-emerald-50">
                              Returned ({loan.returnDate})
                            </span>
                          ) : isOverdue ? (
                            <span className="text-[9px] font-sans font-bold uppercase tracking-wider px-2 py-0.5 border border-red-700 text-red-800 bg-red-100">
                              {overdueDays} Days Overdue
                            </span>
                          ) : (
                            <span className="text-[9px] font-sans font-bold uppercase tracking-wider px-2 py-0.5 border border-[#1A1A1A]/30 text-[#1A1A1A]">
                              Active Loan
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Late fee calc */}
                      <td className="px-4 py-4">
                        {feeData.fee > 0 ? (
                          <div>
                            <div className="font-serif-display font-bold italic text-base text-red-700">
                              {formatCurrency(feeData.fee, settings.currencySymbol)}
                            </div>
                            <div className="text-[10px] font-sans uppercase text-[#1A1A1A]/50">
                              ${settings.dailyLateFeeRate}/day
                            </div>
                          </div>
                        ) : (
                          <span className="text-[#1A1A1A]/40 text-xs font-sans uppercase tracking-wider">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4 text-right whitespace-nowrap space-x-2">
                        {!isReturned && (
                          <>
                            {/* Return Button */}
                            <button
                              onClick={() => onOpenReturnModal(loan)}
                              className="px-3 py-1.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] text-[10px] font-sans uppercase font-bold tracking-widest inline-flex items-center gap-1 transition-colors"
                              title="Check In this item"
                            >
                              <ArrowDownLeft className="w-3 h-3" /> Return
                            </button>

                            {/* Renew Button */}
                            <button
                              onClick={() => onRenewLoan(loan.id)}
                              disabled={loan.renewalCount >= loan.maxRenewals}
                              className="px-2.5 py-1.5 bg-transparent hover:bg-[#1A1A1A] hover:text-[#FDFCF8] disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-[#1A1A1A] text-[#1A1A1A] border border-[#1A1A1A] text-[10px] font-sans uppercase font-bold tracking-wider inline-flex items-center gap-1 transition-colors"
                              title={`Renew loan (${loan.renewalCount}/${loan.maxRenewals})`}
                            >
                              <RotateCw className="w-3 h-3" /> Renew ({loan.renewalCount}/{loan.maxRenewals})
                            </button>

                            {/* Overdue Reminder Email Button */}
                            {isOverdue && (
                              <button
                                onClick={() => onSendReminder(loan)}
                                className="px-2.5 py-1.5 bg-red-800 hover:bg-red-900 text-white text-[10px] font-sans uppercase font-bold tracking-widest inline-flex items-center gap-1 transition-colors"
                                title="Send automated overdue email reminder"
                              >
                                <Mail className="w-3 h-3 text-white" />
                                {loan.remindersSentCount > 0 ? `Notice (${loan.remindersSentCount})` : 'Notice'}
                              </button>
                            )}
                          </>
                        )}
                        {isReturned && (
                          <span className="text-[#1A1A1A]/40 text-[10px] font-sans uppercase tracking-widest">
                            Archived
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
