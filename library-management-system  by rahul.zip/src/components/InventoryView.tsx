import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Printer,
  Edit,
  Trash2,
  CheckCircle,
  AlertCircle,
  LayoutGrid,
  List,
  ArrowRight,
  Barcode,
  MapPin,
  Calendar,
  Layers,
  BookMarked
} from 'lucide-react';
import { Book } from '../types';
import { BarcodeRenderer } from './BarcodeRenderer';

interface InventoryViewProps {
  books: Book[];
  searchQuery: string;
  onAddNewBook: () => void;
  onEditBook: (book: Book) => void;
  onDeleteBook: (bookId: string) => void;
  onPrintBarcode: (book: Book) => void;
  onIssueBook: (book: Book) => void;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  books,
  searchQuery,
  onAddNewBook,
  onEditBook,
  onDeleteBook,
  onPrintBarcode,
  onIssueBook,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [availabilityFilter, setAvailabilityFilter] = useState<'all' | 'available' | 'borrowed'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Categories list
  const categories = ['All', ...Array.from(new Set(books.map(b => b.category)))];

  // Filtering
  const filteredBooks = books.filter(b => {
    const matchesSearch =
      !searchQuery ||
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.isbn.includes(searchQuery) ||
      b.shelfLocation.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || b.category === selectedCategory;

    const matchesAvailability =
      availabilityFilter === 'all' ||
      (availabilityFilter === 'available' && b.availableCopies > 0) ||
      (availabilityFilter === 'borrowed' && b.availableCopies < b.totalCopies);

    return matchesSearch && matchesCategory && matchesAvailability;
  });

  // Analytics
  const totalTitles = books.length;
  const totalPhysicalCopies = books.reduce((acc, b) => acc + b.totalCopies, 0);
  const totalAvailableCopies = books.reduce((acc, b) => acc + b.availableCopies, 0);
  const totalBorrowedCopies = totalPhysicalCopies - totalAvailableCopies;
  const availabilityRate = totalPhysicalCopies > 0 ? Math.round((totalAvailableCopies / totalPhysicalCopies) * 100) : 0;

  return (
    <div className="space-y-8">
      {/* Editorial Inventory Summary Grid */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-[#1A1A1A] pb-3 mb-6">
          <h2 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
            Inventory Summary &amp; Holdings
          </h2>
          <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 sm:mt-0">
            Catalog Status: Fully Indexed
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x divide-[#1A1A1A]/20">
          <div className="pt-2 sm:pt-0 sm:pr-4">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {totalTitles.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Registered Works (Titles)
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {totalPhysicalCopies.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Physical Volumes
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-emerald-800">
              {totalAvailableCopies.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              On Shelf Ready ({availabilityRate}% Available)
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:pl-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-amber-900">
              {totalBorrowedCopies.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Currently Circulating
            </span>
          </div>
        </div>
      </div>

      {/* Control Bar: Editorial Filter Strip & Action Buttons */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-4 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        {/* Category & Status Pills */}
        <div className="flex flex-wrap items-center gap-2 flex-1">
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 md:pb-0">
            {categories.slice(0, 6).map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-sans uppercase tracking-wider transition-colors whitespace-nowrap border ${
                  selectedCategory === cat
                    ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A] font-bold'
                    : 'bg-transparent text-[#1A1A1A]/80 border-[#1A1A1A]/30 hover:border-[#1A1A1A]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="h-5 w-px bg-[#1A1A1A]/20 hidden sm:block"></div>

          {/* Availability Toggle */}
          <div className="flex items-center border border-[#1A1A1A] p-0.5 text-xs font-sans uppercase tracking-wider">
            <button
              onClick={() => setAvailabilityFilter('all')}
              className={`px-2.5 py-1 transition-all ${
                availabilityFilter === 'all' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setAvailabilityFilter('available')}
              className={`px-2.5 py-1 transition-all ${
                availabilityFilter === 'available' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              In Stock
            </button>
            <button
              onClick={() => setAvailabilityFilter('borrowed')}
              className={`px-2.5 py-1 transition-all ${
                availabilityFilter === 'borrowed' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              Issued
            </button>
          </div>
        </div>

        {/* View Switcher & Catalog Action */}
        <div className="flex items-center gap-3 self-end md:self-auto shrink-0">
          <div className="flex items-center border border-[#1A1A1A] p-0.5 text-[#1A1A1A]">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 transition-colors ${viewMode === 'grid' ? 'bg-[#1A1A1A] text-[#FDFCF8]' : 'hover:bg-[#1A1A1A]/10'}`}
              title="Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 transition-colors ${viewMode === 'table' ? 'bg-[#1A1A1A] text-[#FDFCF8]' : 'hover:bg-[#1A1A1A]/10'}`}
              title="Table View"
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            id="add-new-book-btn"
            onClick={onAddNewBook}
            className="px-4 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            Catalog Volume
          </button>
        </div>
      </div>

      {/* Book Presentation */}
      {filteredBooks.length === 0 ? (
        <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-12 text-center space-y-4">
          <BookOpen className="w-10 h-10 text-[#1A1A1A]/40 mx-auto" />
          <h3 className="text-xl font-serif-display font-bold text-[#1A1A1A]">No Works Found in Catalog</h3>
          <p className="text-xs font-sans text-[#1A1A1A]/60 max-w-sm mx-auto">
            No items match your active search and filter constraints. Adjust query terms or catalog a new volume.
          </p>
          <button
            onClick={onAddNewBook}
            className="px-4 py-2 bg-[#1A1A1A] text-[#FDFCF8] text-xs font-sans uppercase tracking-widest font-bold inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Catalog Volume
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBooks.map((book) => {
            const isAvailable = book.availableCopies > 0;
            return (
              <div
                key={book.id}
                id={`book-card-${book.id}`}
                className="border border-[#1A1A1A] bg-[#FDFCF8] flex flex-col justify-between hover:shadow-md transition-shadow group"
              >
                {/* Book Card Top Content */}
                <div className="p-6 space-y-4 border-b border-[#1A1A1A]">
                  <div className="flex items-start justify-between gap-2 border-b border-[#1A1A1A]/15 pb-2">
                    <span className="text-[10px] font-sans uppercase tracking-[0.15em] text-[#1A1A1A]/70 font-semibold">
                      {book.category}
                    </span>
                    <span
                      className={`text-[10px] font-sans uppercase tracking-widest font-bold px-2 py-0.5 ${
                        isAvailable
                          ? 'border border-emerald-800 text-emerald-900 bg-emerald-50'
                          : 'border border-red-700 text-red-800 bg-red-50'
                      }`}
                    >
                      {isAvailable ? `${book.availableCopies} of ${book.totalCopies} Available` : 'All Issued'}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-serif-display text-2xl font-bold italic text-[#1A1A1A] leading-tight group-hover:underline">
                      {book.title}
                    </h3>
                    <p className="text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/60 mt-1">
                      {book.author} — <span className="italic">{book.publishYear}</span>
                    </p>
                  </div>

                  <p className="text-xs font-serif text-[#1A1A1A]/80 line-clamp-2 leading-relaxed italic">
                    "{book.description || 'No archival abstract registered.'}"
                  </p>

                  <div className="pt-2 flex items-center justify-between text-[11px] text-[#1A1A1A]/70 font-sans uppercase tracking-wider border-t border-[#1A1A1A]/10">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-[#1A1A1A]" />
                      {book.shelfLocation}
                    </span>
                    <span className="font-mono text-[10px]">ISBN: {book.isbn}</span>
                  </div>
                </div>

                {/* Barcode Snippet Preview */}
                <div className="px-6 py-3 bg-[#FDFCF8] border-b border-[#1A1A1A] flex items-center justify-between">
                  <div className="scale-85 origin-left">
                    <BarcodeRenderer
                      value={book.isbn}
                      width={1.1}
                      height={24}
                      fontSize={9}
                      className="border-none shadow-none bg-transparent"
                    />
                  </div>
                  <button
                    onClick={() => onPrintBarcode(book)}
                    className="p-1.5 text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-[#FDFCF8] border border-[#1A1A1A] text-[10px] uppercase font-sans tracking-widest flex items-center gap-1 transition-colors"
                    title="Print Spine Barcode Tag"
                  >
                    <Printer className="w-3 h-3" />
                    <span>Tag</span>
                  </button>
                </div>

                {/* Bottom Action Footer */}
                <div className="p-4 px-6 bg-[#FDFCF8] flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onEditBook(book)}
                      className="p-1.5 text-[#1A1A1A]/70 hover:text-[#1A1A1A] border border-[#1A1A1A]/30 hover:border-[#1A1A1A] transition-colors"
                      title="Edit Book Details"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDeleteBook(book.id)}
                      className="p-1.5 text-[#1A1A1A]/50 hover:text-red-700 border border-[#1A1A1A]/20 hover:border-red-600 transition-colors"
                      title="Remove from Catalog"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {isAvailable ? (
                    <button
                      onClick={() => onIssueBook(book)}
                      className="px-3.5 py-1.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] text-[11px] font-sans font-bold uppercase tracking-widest flex items-center gap-1.5 transition-colors"
                    >
                      Issue <ArrowRight className="w-3 h-3" />
                    </button>
                  ) : (
                    <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/40">
                      Circulating
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Detailed Editorial Table View */
        <div className="border border-[#1A1A1A] bg-[#FDFCF8] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="text-[10px] font-sans uppercase tracking-widest border-b border-[#1A1A1A] text-[#1A1A1A] bg-[#1A1A1A]/5">
                  <th className="px-6 py-3 font-normal">Catalog Title &amp; Author</th>
                  <th className="px-4 py-3 font-normal">Category</th>
                  <th className="px-4 py-3 font-normal">ISBN Barcode</th>
                  <th className="px-4 py-3 font-normal">Shelf Location</th>
                  <th className="px-4 py-3 text-center font-normal">Copies Available</th>
                  <th className="px-6 py-3 text-right font-normal">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]/15">
                {filteredBooks.map((b) => (
                  <tr key={b.id} className="hover:bg-[#1A1A1A]/5 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-serif-display font-bold italic text-base text-[#1A1A1A]">{b.title}</div>
                      <div className="text-[#1A1A1A]/60 text-[11px] font-sans uppercase tracking-wider mt-0.5">{b.author} ({b.publishYear})</div>
                    </td>
                    <td className="px-4 py-4">
                      <span className="text-[10px] font-sans uppercase tracking-wider text-[#1A1A1A] border border-[#1A1A1A]/30 px-2 py-0.5">
                        {b.category}
                      </span>
                    </td>
                    <td className="px-4 py-4 font-mono text-[11px] text-[#1A1A1A]">
                      {b.isbn}
                    </td>
                    <td className="px-4 py-4 text-[#1A1A1A] font-sans text-xs">
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#1A1A1A]" />
                        {b.shelfLocation}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-center">
                      <span
                        className={`text-[10px] font-sans uppercase tracking-widest font-bold px-2 py-0.5 ${
                          b.availableCopies > 0
                            ? 'border border-emerald-800 text-emerald-900 bg-emerald-50'
                            : 'border border-red-700 text-red-800 bg-red-50'
                        }`}
                      >
                        {b.availableCopies} of {b.totalCopies}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right space-x-2">
                      <button
                        onClick={() => onPrintBarcode(b)}
                        className="p-1.5 text-[#1A1A1A] border border-[#1A1A1A]/30 hover:border-[#1A1A1A] transition-colors"
                        title="Print Barcode Tag"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onEditBook(b)}
                        className="p-1.5 text-[#1A1A1A] border border-[#1A1A1A]/30 hover:border-[#1A1A1A] transition-colors"
                        title="Edit Book"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      {b.availableCopies > 0 && (
                        <button
                          onClick={() => onIssueBook(b)}
                          className="px-3 py-1 bg-[#1A1A1A] text-[#FDFCF8] text-[10px] font-sans uppercase font-bold tracking-widest hover:bg-neutral-800 transition-colors"
                        >
                          Issue
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
