import React, { useState, useEffect } from 'react';
import { X, UserPlus, Edit3, UserCheck, ShieldAlert } from 'lucide-react';
import { Member, MemberRole, MemberStatus } from '../types';

interface MemberFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveMember: (memberData: Omit<Member, 'id'>, existingId?: string) => void;
  editingMember?: Member | null;
}

export const MemberFormModal: React.FC<MemberFormModalProps> = ({
  isOpen,
  onClose,
  onSaveMember,
  editingMember,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<MemberRole>('Student');
  const [status, setStatus] = useState<MemberStatus>('Active');
  const [memberCode, setMemberCode] = useState('');
  const [department, setDepartment] = useState('');
  const [maxBorrowLimit, setMaxBorrowLimit] = useState<number>(4);

  useEffect(() => {
    if (isOpen) {
      if (editingMember) {
        setName(editingMember.name);
        setEmail(editingMember.email);
        setPhone(editingMember.phone);
        setRole(editingMember.role);
        setStatus(editingMember.status);
        setMemberCode(editingMember.memberCode);
        setDepartment(editingMember.departmentOrProgram || '');
        setMaxBorrowLimit(editingMember.maxBorrowLimit);
      } else {
        const randNum = Math.floor(1000 + Math.random() * 9000);
        setName('');
        setEmail('');
        setPhone('+1 (555) 000-0000');
        setRole('Student');
        setStatus('Active');
        setMemberCode(`LIB-STU-${randNum}`);
        setDepartment('Computer Science Department');
        setMaxBorrowLimit(4);
      }
    }
  }, [isOpen, editingMember]);

  // Adjust max borrow default when role changes
  const handleRoleChange = (newRole: MemberRole) => {
    setRole(newRole);
    if (!editingMember) {
      if (newRole === 'Student') setMaxBorrowLimit(4);
      else if (newRole === 'Faculty') setMaxBorrowLimit(10);
      else if (newRole === 'Researcher') setMaxBorrowLimit(8);
      else setMaxBorrowLimit(2);

      const prefix = newRole === 'Student' ? 'STU' : newRole === 'Faculty' ? 'FAC' : newRole === 'Researcher' ? 'RES' : 'COM';
      const randNum = Math.floor(1000 + Math.random() * 9000);
      setMemberCode(`LIB-${prefix}-${randNum}`);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !memberCode.trim()) return;

    onSaveMember(
      {
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        role,
        status,
        memberCode: memberCode.trim(),
        departmentOrProgram: department.trim(),
        maxBorrowLimit: Number(maxBorrowLimit),
        currentBorrowedCount: editingMember ? editingMember.currentBorrowedCount : 0,
        unpaidFines: editingMember ? editingMember.unpaidFines : 0,
        joinedDate: editingMember ? editingMember.joinedDate : new Date().toISOString().split('T')[0],
      },
      editingMember?.id
    );

    onClose();
  };

  return (
    <div id="member-form-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Patron Membership Registry
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              {editingMember ? 'Edit Patron Profile' : 'Register New Patron'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {/* Name */}
          <div>
            <label htmlFor="member-name-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Full Legal Name *
            </label>
            <input
              id="member-name-input"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rachel Adams"
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Email & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="member-email-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Institutional Email *
              </label>
              <input
                id="member-email-input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="rachel.adams@university.edu"
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
              />
            </div>

            <div>
              <label htmlFor="member-phone-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Contact Phone
              </label>
              <input
                id="member-phone-input"
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (555) 123-4567"
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Member Code & Role */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="member-code-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Member Barcode ID *
              </label>
              <input
                id="member-code-input"
                type="text"
                required
                value={memberCode}
                onChange={(e) => setMemberCode(e.target.value)}
                className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-mono focus:outline-hidden"
              />
            </div>

            <div>
              <label htmlFor="member-role-select" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Affiliation Role
              </label>
              <select
                id="member-role-select"
                value={role}
                onChange={(e) => handleRoleChange(e.target.value as MemberRole)}
                className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              >
                <option value="Student">Student (Limit: 4)</option>
                <option value="Faculty">Faculty (Limit: 10)</option>
                <option value="Researcher">Researcher (Limit: 8)</option>
                <option value="Community">Community (Limit: 2)</option>
              </select>
            </div>
          </div>

          {/* Department / Program */}
          <div>
            <label htmlFor="member-dept-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Department / Major / Division
            </label>
            <input
              id="member-dept-input"
              type="text"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              placeholder="e.g. Dept. of Informatics & Computing"
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Status & Max Borrow Limit */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="member-status-select" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Privilege Status
              </label>
              <select
                id="member-status-select"
                value={status}
                onChange={(e) => setStatus(e.target.value as MemberStatus)}
                className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              >
                <option value="Active">Active (Permitted)</option>
                <option value="Suspended">Suspended (Blocked)</option>
                <option value="Expired">Expired</option>
              </select>
            </div>

            <div>
              <label htmlFor="member-borrowlimit-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Loan Capacity Limit
              </label>
              <input
                id="member-borrowlimit-input"
                type="number"
                min={1}
                max={20}
                value={maxBorrowLimit}
                onChange={(e) => setMaxBorrowLimit(Number(e.target.value))}
                className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
            >
              Cancel
            </button>
            <button
              id="save-member-btn"
              type="submit"
              className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest transition-colors shadow-2xs"
            >
              {editingMember ? 'Update Patron Profile' : 'Enroll Patron'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
