import React, { useState, useEffect } from 'react';
import { X, BookPlus, AlertCircle, CheckCircle, Calendar, User, BookOpen } from 'lucide-react';
import { Book, Member, LoanTransaction, SystemSettings } from '../types';

interface IssueBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  books: Book[];
  members: Member[];
  settings: SystemSettings;
  preselectedBook?: Book | null;
  preselectedMember?: Member | null;
  onConfirmIssue: (newLoan: Omit<LoanTransaction, 'id'>) => void;
}

export const IssueBookModal: React.FC<IssueBookModalProps> = ({
  isOpen,
  onClose,
  books,
  members,
  settings,
  preselectedBook,
  preselectedMember,
  onConfirmIssue,
}) => {
  const [selectedBookId, setSelectedBookId] = useState<string>('');
  const [selectedMemberId, setSelectedMemberId] = useState<string>('');
  const [issueDate, setIssueDate] = useState<string>('');
  const [dueDate, setDueDate] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      setIssueDate(todayStr);

      const due = new Date();
      due.setDate(due.getDate() + settings.standardLoanDays);
      setDueDate(due.toISOString().split('T')[0]);

      setSelectedBookId(preselectedBook?.id || (books.find(b => b.availableCopies > 0)?.id || ''));
      setSelectedMemberId(preselectedMember?.id || (members[0]?.id || ''));
      setNotes('');
      setErrorMsg(null);
    }
  }, [isOpen, preselectedBook, preselectedMember, settings.standardLoanDays]);

  if (!isOpen) return null;

  const currentBook = books.find(b => b.id === selectedBookId);
  const currentMember = members.find(m => m.id === selectedMemberId);

  const isBookUnavailable = !currentBook || currentBook.availableCopies <= 0;
  const isMemberOverLimit = currentMember && currentMember.currentBorrowedCount >= currentMember.maxBorrowLimit;
  const isMemberSuspended = currentMember && currentMember.status !== 'Active';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentBook || !currentMember) {
      setErrorMsg('Please select a valid book and patron.');
      return;
    }

    if (currentBook.availableCopies <= 0) {
      setErrorMsg(`"${currentBook.title}" has zero available copies.`);
      return;
    }

    if (currentMember.currentBorrowedCount >= currentMember.maxBorrowLimit) {
      setErrorMsg(`${currentMember.name} has already reached the maximum borrow limit (${currentMember.maxBorrowLimit} books).`);
      return;
    }

    if (currentMember.status !== 'Active') {
      setErrorMsg(`Patron status is ${currentMember.status}. Cannot issue books.`);
      return;
    }

    onConfirmIssue({
      bookId: currentBook.id,
      bookTitle: currentBook.title,
      bookIsbn: currentBook.isbn,
      memberId: currentMember.id,
      memberName: currentMember.name,
      memberEmail: currentMember.email,
      memberCode: currentMember.memberCode,
      issueDate: issueDate,
      dueDate: dueDate,
      status: 'Active',
      renewalCount: 0,
      maxRenewals: settings.maxRenewalsAllowed,
      lateFee: 0,
      lateFeePaid: false,
      notes: notes.trim() || undefined,
      remindersSentCount: 0,
    });

    onClose();
  };

  return (
    <div id="issue-book-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Circulation Registry
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Issue Book (Checkout)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {errorMsg && (
            <div className="p-3 border border-red-700 bg-red-50 flex items-center gap-2 text-xs text-red-800 font-sans">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Book Selector */}
          <div>
            <label htmlFor="issue-select-book" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
              Select Book to Issue *
            </label>
            <div className="relative">
              <select
                id="issue-select-book"
                value={selectedBookId}
                onChange={(e) => setSelectedBookId(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              >
                {books.map((b) => (
                  <option key={b.id} value={b.id} disabled={b.availableCopies <= 0}>
                    {b.title} — ISBN {b.isbn} ({b.availableCopies} of {b.totalCopies} avail)
                  </option>
                ))}
              </select>
            </div>
            {currentBook && (
              <div className="mt-1.5 flex items-center justify-between text-[11px] font-sans text-[#1A1A1A]/60 px-0.5">
                <span>Location: <strong className="text-[#1A1A1A]">{currentBook.shelfLocation}</strong></span>
                <span className={currentBook.availableCopies > 0 ? 'text-emerald-800 font-bold' : 'text-red-700 font-bold'}>
                  {currentBook.availableCopies > 0 ? `In Stock (${currentBook.availableCopies} copies available)` : 'Out of Stock'}
                </span>
              </div>
            )}
          </div>

          {/* Patron Selector */}
          <div>
            <label htmlFor="issue-select-member" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
              Borrowing Patron / Member *
            </label>
            <select
              id="issue-select-member"
              value={selectedMemberId}
              onChange={(e) => setSelectedMemberId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
            >
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({m.role}) — {m.memberCode} [{m.currentBorrowedCount}/{m.maxBorrowLimit} books]
                </option>
              ))}
            </select>
            {currentMember && (
              <div className="mt-1.5 flex items-center justify-between text-[11px] font-sans text-[#1A1A1A]/60 px-0.5">
                <span>Account Status: <strong className="text-[#1A1A1A]">{currentMember.status}</strong></span>
                <span className={isMemberOverLimit ? 'text-red-700 font-bold' : 'text-[#1A1A1A]'}>
                  Current Loans: {currentMember.currentBorrowedCount} / {currentMember.maxBorrowLimit} maximum
                </span>
              </div>
            )}
          </div>

          {/* Dates row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="issue-date-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
                Issue Date
              </label>
              <input
                id="issue-date-input"
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>
            <div>
              <label htmlFor="due-date-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
                Due Date ({settings.standardLoanDays} Days Standard)
              </label>
              <input
                id="due-date-input"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label htmlFor="issue-notes-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
              Circulation Notes (Optional)
            </label>
            <input
              id="issue-notes-input"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Semester course reserve, thesis reference"
              className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
            >
              Cancel
            </button>
            <button
              id="confirm-issue-loan-btn"
              type="submit"
              disabled={isBookUnavailable || isMemberOverLimit || isMemberSuspended}
              className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 disabled:opacity-40 disabled:cursor-not-allowed text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest transition-colors shadow-2xs"
            >
              Complete Checkout
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
