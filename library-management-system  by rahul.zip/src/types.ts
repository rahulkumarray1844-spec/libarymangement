export type BookStatus = 'Available' | 'Borrowed' | 'Low Stock' | 'Reserved' | 'Maintenance';

export interface Book {
  id: string;
  isbn: string; // 13-digit or standard barcode
  title: string;
  author: string;
  category: string;
  publishYear: number;
  shelfLocation: string; // e.g. "Aisle 3 - Shelf B4"
  totalCopies: number;
  availableCopies: number;
  description: string;
  publisher?: string;
  coverColor?: string; // fallback visual accent
  addedDate: string;
}

export type MemberRole = 'Student' | 'Faculty' | 'Community' | 'Researcher';
export type MemberStatus = 'Active' | 'Suspended' | 'Expired';

export interface Member {
  id: string;
  memberCode: string; // e.g. "LIB-M0842"
  name: string;
  email: string;
  phone: string;
  role: MemberRole;
  status: MemberStatus;
  joinedDate: string;
  maxBorrowLimit: number;
  currentBorrowedCount: number;
  unpaidFines: number;
  departmentOrProgram?: string;
}

export type LoanStatus = 'Active' | 'Returned' | 'Overdue' | 'Lost';

export interface LoanTransaction {
  id: string;
  bookId: string;
  bookTitle: string;
  bookIsbn: string;
  memberId: string;
  memberName: string;
  memberEmail: string;
  memberCode: string;
  issueDate: string; // ISO YYYY-MM-DD
  dueDate: string;   // ISO YYYY-MM-DD
  returnDate?: string; // ISO YYYY-MM-DD
  status: LoanStatus;
  renewalCount: number;
  maxRenewals: number;
  lateFee: number;
  lateFeePaid: boolean;
  notes?: string;
  remindersSentCount: number;
  lastReminderSentDate?: string;
}

export interface LateFeePayment {
  id: string;
  loanId: string;
  memberId: string;
  memberName: string;
  bookTitle: string;
  amount: number;
  paymentDate: string;
  method: 'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived';
  receiptNumber: string;
  notes?: string;
}

export interface EmailReminder {
  id: string;
  loanId: string;
  memberId: string;
  memberEmail: string;
  memberName: string;
  bookTitle: string;
  dueDate: string;
  daysOverdue: number;
  fineAmount: number;
  sentAt: string;
  status: 'Sent' | 'Delivered' | 'Failed';
  subject: string;
  bodySnippet: string;
}

export interface SystemSettings {
  libraryName: string;
  dailyLateFeeRate: number; // e.g. $0.50 per day
  gracePeriodDays: number;  // e.g. 1 day
  standardLoanDays: number; // e.g. 14 days
  maxRenewalsAllowed: number; // e.g. 2
  autoReminderEnabled: boolean;
  reminderFrequencyDays: number; // e.g. send every 3 days
  contactEmail: string;
  currencySymbol: string;
}
