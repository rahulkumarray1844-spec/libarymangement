import React, { useState, useEffect, useRef } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Camera, X, RefreshCw, Upload, Keyboard, CheckCircle2, AlertCircle, BookOpen, User, ArrowRight } from 'lucide-react';
import { Book, Member } from '../types';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanResult: (code: string) => void;
  books: Book[];
  members: Member[];
  onSelectBookForIssue?: (book: Book) => void;
  onSelectBookForReturn?: (book: Book) => void;
  onSelectMember?: (member: Member) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScanResult,
  books,
  members,
  onSelectBookForIssue,
  onSelectBookForReturn,
  onSelectMember,
}) => {
  const [activeTab, setActiveTab] = useState<'camera' | 'upload' | 'manual' | 'sample'>('camera');
  const [manualInput, setManualInput] = useState('');
  const [scanStatus, setScanStatus] = useState<string>('Ready to scan');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [detectedItem, setDetectedItem] = useState<{
    code: string;
    type: 'book' | 'member' | 'unknown';
    book?: Book;
    member?: Member;
  } | null>(null);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop camera when closing or switching tabs
  const stopCamera = async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        await scannerRef.current.clear();
      } catch (e) {
        console.warn('Error stopping scanner:', e);
      }
      scannerRef.current = null;
      setIsScanning(false);
    }
  };

  const handleDetectedCode = (code: string) => {
    const trimmed = code.trim();
    if (!trimmed) return;

    // Check if matching book ISBN or memberCode
    const bookMatch = books.find(b => b.isbn === trimmed || b.id === trimmed);
    const memberMatch = members.find(m => m.memberCode === trimmed || m.id === trimmed);

    if (bookMatch) {
      setDetectedItem({ code: trimmed, type: 'book', book: bookMatch });
    } else if (memberMatch) {
      setDetectedItem({ code: trimmed, type: 'member', member: memberMatch });
    } else {
      setDetectedItem({ code: trimmed, type: 'unknown' });
    }

    onScanResult(trimmed);
  };

  // Start live camera
  const startCamera = async () => {
    setCameraError(null);
    setScanStatus('Initializing camera...');
    try {
      await stopCamera();

      const qrCodeElementId = 'reader-viewport';
      const element = document.getElementById(qrCodeElementId);
      if (!element) return;

      const html5QrCode = new Html5Qrcode(qrCodeElementId, {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.QR_CODE,
        ],
        verbose: false,
      });

      scannerRef.current = html5QrCode;

      const config = {
        fps: 10,
        qrbox: { width: 260, height: 160 },
        aspectRatio: 1.333,
      };

      await html5QrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          handleDetectedCode(decodedText);
          setScanStatus(`Scanned: ${decodedText}`);
        },
        (errorMessage) => {
          // ignore transient frame decode errors
        }
      );

      setIsScanning(true);
      setScanStatus('Align barcode within the target frame');
    } catch (err: any) {
      console.error('Camera start error:', err);
      setCameraError(
        err?.message || 'Unable to access camera. Please verify camera permissions or use manual barcode input.'
      );
      setIsScanning(false);
    }
  };

  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      const timer = setTimeout(() => {
        startCamera();
      }, 200);
      return () => {
        clearTimeout(timer);
        stopCamera();
      };
    } else {
      stopCamera();
    }
  }, [isOpen, activeTab]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setScanStatus('Analyzing image file...');
      const html5QrCode = new Html5Qrcode('file-scanner-temp');
      const result = await html5QrCode.scanFile(file, true);
      handleDetectedCode(result);
      setScanStatus(`Barcode detected: ${result}`);
    } catch (err) {
      setCameraError('No valid barcode or QR code detected in the selected image.');
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualInput.trim()) {
      handleDetectedCode(manualInput.trim());
      setManualInput('');
    }
  };

  if (!isOpen) return null;

  return (
    <div id="barcode-scanner-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in duration-150">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Optical Input Terminal
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Barcode &amp; RFID Scanner
            </h2>
          </div>
          <button
            id="close-barcode-scanner-btn"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#1A1A1A] bg-[#FDFCF8] overflow-x-auto text-xs font-sans uppercase tracking-wider">
          <button
            id="tab-scanner-camera"
            onClick={() => setActiveTab('camera')}
            className={`py-3 px-4 border-r border-[#1A1A1A] transition-all flex items-center gap-1.5 ${
              activeTab === 'camera'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            Live Camera
          </button>
          <button
            id="tab-scanner-manual"
            onClick={() => setActiveTab('manual')}
            className={`py-3 px-4 border-r border-[#1A1A1A] transition-all flex items-center gap-1.5 ${
              activeTab === 'manual'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <Keyboard className="w-3.5 h-3.5" />
            Manual / USB Gun
          </button>
          <button
            id="tab-scanner-upload"
            onClick={() => setActiveTab('upload')}
            className={`py-3 px-4 border-r border-[#1A1A1A] transition-all flex items-center gap-1.5 ${
              activeTab === 'upload'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            Upload Photo
          </button>
          <button
            id="tab-scanner-sample"
            onClick={() => setActiveTab('sample')}
            className={`py-3 px-4 transition-all flex items-center gap-1.5 ${
              activeTab === 'sample'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Catalog Test
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* CAMERA TAB */}
          {activeTab === 'camera' && (
            <div className="space-y-3">
              <div className="relative bg-slate-900 rounded-xl overflow-hidden min-h-[260px] flex items-center justify-center border border-slate-800">
                <div id="reader-viewport" className="w-full max-w-md mx-auto aspect-4/3"></div>
                {!isScanning && !cameraError && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/80 text-white p-4 text-center">
                    <RefreshCw className="w-8 h-8 animate-spin text-amber-400 mb-2" />
                    <p className="text-sm font-medium">Requesting camera stream...</p>
                  </div>
                )}
                {cameraError && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/90 text-white p-6 text-center space-y-3">
                    <AlertCircle className="w-10 h-10 text-amber-400" />
                    <p className="text-sm font-medium text-slate-200">{cameraError}</p>
                    <button
                      onClick={startCamera}
                      className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold"
                    >
                      Retry Camera
                    </button>
                  </div>
                )}
              </div>
              <p className="text-xs text-center text-slate-500">{scanStatus}</p>
            </div>
          )}

          {/* MANUAL / USB GUN TAB */}
          {activeTab === 'manual' && (
            <form onSubmit={handleManualSubmit} className="space-y-4 py-2">
              <div>
                <label htmlFor="manual-barcode-input" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Type or Scan Barcode / ISBN / Member ID
                </label>
                <div className="flex gap-2">
                  <input
                    id="manual-barcode-input"
                    type="text"
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    placeholder="e.g. 9780134685991 or LIB-STU-1084"
                    autoFocus
                    className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  />
                  <button
                    id="submit-manual-barcode-btn"
                    type="submit"
                    className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-medium rounded-xl text-sm transition-colors shadow-xs"
                  >
                    Lookup
                  </button>
                </div>
                <p className="text-xs text-slate-400 mt-2">
                  Physical handheld USB scanners automatically inject the code and send an Enter keystroke.
                </p>
              </div>
            </form>
          )}

          {/* UPLOAD PHOTO TAB */}
          {activeTab === 'upload' && (
            <div className="space-y-4 py-4 text-center">
              <div id="file-scanner-temp" className="hidden"></div>
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-amber-500 rounded-2xl p-8 cursor-pointer bg-slate-50/50 hover:bg-amber-50/30 transition-all flex flex-col items-center justify-center space-y-2"
              >
                <Upload className="w-8 h-8 text-slate-400" />
                <p className="text-sm font-semibold text-slate-700">Click to upload barcode photo</p>
                <p className="text-xs text-slate-400">Supports PNG, JPG, WEBP with clear ISBN or Code 128</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            </div>
          )}

          {/* CATALOG QUICK TEST TAB */}
          {activeTab === 'sample' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Simulate Scanning Book ISBNs</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {books.slice(0, 4).map(b => (
                    <button
                      key={b.id}
                      onClick={() => handleDetectedCode(b.isbn)}
                      className="text-left p-2.5 rounded-lg border border-slate-200 hover:border-amber-400 bg-slate-50 hover:bg-amber-50/50 transition-colors text-xs space-y-0.5"
                    >
                      <div className="font-semibold text-slate-800 truncate">{b.title}</div>
                      <div className="font-mono text-slate-500 text-[11px]">{b.isbn} · {b.availableCopies} avail</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Simulate Scanning Patron IDs</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {members.slice(0, 4).map(m => (
                    <button
                      key={m.id}
                      onClick={() => handleDetectedCode(m.memberCode)}
                      className="text-left p-2.5 rounded-lg border border-slate-200 hover:border-amber-400 bg-slate-50 hover:bg-amber-50/50 transition-colors text-xs space-y-0.5"
                    >
                      <div className="font-semibold text-slate-800">{m.name} ({m.role})</div>
                      <div className="font-mono text-slate-500 text-[11px]">{m.memberCode}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* DETECTED RESULT CARD */}
          {detectedItem && (
            <div className="mt-4 p-4 rounded-xl border border-amber-200 bg-amber-50/60 transition-all animate-in fade-in">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2 text-amber-900 font-semibold text-sm mb-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Code Detected: <span className="font-mono">{detectedItem.code}</span></span>
                </div>
              </div>

              {detectedItem.type === 'book' && detectedItem.book && (
                <div className="mt-2 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-slate-700">
                    <BookOpen className="w-4 h-4 text-amber-700" />
                    <span className="font-bold text-sm text-slate-900">{detectedItem.book.title}</span>
                  </div>
                  <p className="text-slate-600">
                    Author: <span className="font-medium">{detectedItem.book.author}</span> · Shelf: <span className="font-medium">{detectedItem.book.shelfLocation}</span>
                  </p>
                  <p className="text-slate-600">
                    Stock: <span className={`font-bold ${detectedItem.book.availableCopies > 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {detectedItem.book.availableCopies} of {detectedItem.book.totalCopies} available
                    </span>
                  </p>

                  <div className="pt-2 flex flex-wrap gap-2">
                    {detectedItem.book.availableCopies > 0 && onSelectBookForIssue && (
                      <button
                        onClick={() => {
                          onSelectBookForIssue(detectedItem.book!);
                          stopCamera();
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium flex items-center gap-1.5 transition-colors shadow-2xs"
                      >
                        Issue This Book <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {onSelectBookForReturn && (
                      <button
                        onClick={() => {
                          onSelectBookForReturn(detectedItem.book!);
                          stopCamera();
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-medium flex items-center gap-1.5 transition-colors shadow-2xs"
                      >
                        Return / Check In <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              )}

              {detectedItem.type === 'member' && detectedItem.member && (
                <div className="mt-2 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-slate-700">
                    <User className="w-4 h-4 text-amber-700" />
                    <span className="font-bold text-sm text-slate-900">{detectedItem.member.name}</span>
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full font-medium">
                      {detectedItem.member.role}
                    </span>
                  </div>
                  <p className="text-slate-600">
                    Code: <span className="font-mono">{detectedItem.member.memberCode}</span> · Email: {detectedItem.member.email}
                  </p>
                  <p className="text-slate-600">
                    Active Loans: <span className="font-semibold text-slate-800">{detectedItem.member.currentBorrowedCount} / {detectedItem.member.maxBorrowLimit}</span>
                    {detectedItem.member.unpaidFines > 0 && (
                      <span className="text-rose-600 font-bold ml-2">Unpaid Fines: ${detectedItem.member.unpaidFines.toFixed(2)}</span>
                    )}
                  </p>

                  {onSelectMember && (
                    <div className="pt-2">
                      <button
                        onClick={() => {
                          onSelectMember(detectedItem.member!);
                          stopCamera();
                          onClose();
                        }}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium flex items-center gap-1.5 transition-colors shadow-2xs"
                      >
                        Select Member for Checkout <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {detectedItem.type === 'unknown' && (
                <div className="mt-2 text-xs text-slate-600">
                  Code recognized, but no matching book ISBN or member ID was found in catalog.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Barcode scanner supports EAN-13, Code 128, Code 39 & QR codes</span>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="px-4 py-1.5 text-slate-600 hover:text-slate-900 font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
