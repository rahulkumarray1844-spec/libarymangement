import React from 'react';
import { X, Printer, ShieldCheck, UserCheck, BookMarked } from 'lucide-react';
import { Member } from '../types';
import { BarcodeRenderer } from './BarcodeRenderer';

interface MemberCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  member: Member | null;
}

export const MemberCardModal: React.FC<MemberCardModalProps> = ({
  isOpen,
  onClose,
  member,
}) => {
  if (!isOpen || !member) return null;

  return (
    <div id="member-card-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Patron Identity Credential
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Library Reader Pass
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Body */}
        <div className="p-6 bg-[#1A1A1A]/5 flex flex-col items-center">
          <div
            id="digital-patron-pass"
            className="w-full bg-[#FDFCF8] text-[#1A1A1A] p-6 border-2 border-[#1A1A1A] flex flex-col justify-between aspect-16/10 relative overflow-hidden shadow-2xs"
          >
            <div className="flex justify-between items-start border-b border-[#1A1A1A] pb-2">
              <div>
                <p className="text-[9px] uppercase font-sans font-bold tracking-[0.25em] text-[#1A1A1A]/70">Central Library</p>
                <h3 className="text-xs font-serif italic text-[#1A1A1A]">Official Reader Pass</h3>
              </div>
              <span className="px-2 py-0.5 border border-[#1A1A1A] text-[9px] font-sans font-bold tracking-widest uppercase bg-[#1A1A1A] text-[#FDFCF8]">
                {member.role}
              </span>
            </div>

            <div className="my-3">
              <h2 className="text-xl font-black italic font-serif-display tracking-tight text-[#1A1A1A]">{member.name}</h2>
              <p className="text-[11px] font-sans text-[#1A1A1A]/70">{member.departmentOrProgram || member.email}</p>
            </div>

            {/* Barcode on card */}
            <div className="bg-[#FDFCF8] border border-[#1A1A1A] p-2 flex flex-col items-center">
              <BarcodeRenderer
                value={member.memberCode}
                width={1.6}
                height={38}
                fontSize={11}
                className="border-none shadow-none bg-transparent"
              />
            </div>

            <div className="flex justify-between items-center text-[9px] text-[#1A1A1A]/60 font-mono pt-2 border-t border-[#1A1A1A]">
              <span>Issued: {member.joinedDate}</span>
              <span>Status: <strong className="text-[#1A1A1A] uppercase">{member.status}</strong></span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#1A1A1A] flex items-center justify-between">
          <span className="text-[11px] font-sans text-[#1A1A1A]/60">Valid across all campus branches</span>
          <button
            onClick={() => window.print()}
            className="px-5 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-2 transition-colors shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Pass
          </button>
        </div>
      </div>
    </div>
  );
};
