import React, { useState } from 'react';
import {
  Database,
  Download,
  Code2,
  Table,
  Play,
  Copy,
  Check,
  FileCode,
  Layers,
  Terminal
} from 'lucide-react';
import { Book, Member, LoanTransaction, SystemSettings } from '../types';
import { generateSqlDump } from '../utils/lateFeeCalculator';

interface DatabaseSqlViewProps {
  books: Book[];
  members: Member[];
  loans: LoanTransaction[];
  settings: SystemSettings;
}

export const DatabaseSqlView: React.FC<DatabaseSqlViewProps> = ({
  books,
  members,
  loans,
  settings,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'tables' | 'query' | 'schema' | 'jdbc'>('tables');
  const [copied, setCopied] = useState(false);
  const [selectedTable, setSelectedTable] = useState<'books' | 'members' | 'loans'>('books');
  const [customSql, setCustomSql] = useState(
    "SELECT book_title, member_name, due_date, status, late_fee FROM loan_transactions WHERE status = 'Overdue';"
  );
  const [queryResult, setQueryResult] = useState<any[] | null>(null);

  const sqlDump = generateSqlDump(books, members, loans, settings);

  const handleDownloadSql = () => {
    const blob = new Blob([sqlDump], { type: 'text/sql;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `library_database_dump_${new Date().toISOString().split('T')[0]}.sql`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlDump);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Run in-memory query engine
  const handleExecuteQuery = () => {
    const q = customSql.toLowerCase().trim();
    if (q.includes('from loan_transactions') || q.includes('from loans')) {
      if (q.includes("status = 'overdue'")) {
        setQueryResult(
          loans
            .filter(l => l.status === 'Overdue')
            .map(l => ({
              book_title: l.bookTitle,
              member_name: l.memberName,
              due_date: l.dueDate,
              status: l.status,
              late_fee: `$${l.lateFee.toFixed(2)}`,
            }))
        );
      } else {
        setQueryResult(
          loans.map(l => ({
            id: l.id,
            book_title: l.bookTitle,
            member_name: l.memberName,
            due_date: l.dueDate,
            status: l.status,
            late_fee: `$${l.lateFee.toFixed(2)}`,
          }))
        );
      }
    } else if (q.includes('from books')) {
      setQueryResult(
        books.map(b => ({
          isbn: b.isbn,
          title: b.title,
          author: b.author,
          category: b.category,
          total_copies: b.totalCopies,
          available_copies: b.availableCopies,
          shelf_location: b.shelfLocation,
        }))
      );
    } else if (q.includes('from members')) {
      setQueryResult(
        members.map(m => ({
          member_code: m.memberCode,
          name: m.name,
          email: m.email,
          role: m.role,
          borrowed: m.currentBorrowedCount,
          unpaid_fines: `$${m.unpaidFines.toFixed(2)}`,
        }))
      );
    } else {
      setQueryResult([
        { query: 'Executed successfully', rows_affected: 0, execution_time: '1.2ms' }
      ]);
    }
  };

  const sampleJdbcCode = `// ===============================================================
// Java (Swing/JavaFX) JDBC Connector & DAO Architecture
// Database: SQLite 3 / MySQL (Connector/J)
// ===============================================================

package com.library.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    // SQLite connection string (or "jdbc:mysql://localhost:3306/library_db")
    private static final String URL = "jdbc:sqlite:library.db";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite JDBC Driver not found", e);
        }
        return DriverManager.getConnection(URL);
    }

    public static void initializeSchema() {
        String schema = 
            "CREATE TABLE IF NOT EXISTS books (" +
            "  id TEXT PRIMARY KEY, " +
            "  isbn TEXT UNIQUE NOT NULL, " +
            "  title TEXT NOT NULL, " +
            "  author TEXT NOT NULL, " +
            "  total_copies INTEGER NOT NULL, " +
            "  available_copies INTEGER NOT NULL" +
            ");" +
            "CREATE TABLE IF NOT EXISTS loan_transactions (" +
            "  id TEXT PRIMARY KEY, " +
            "  book_id TEXT REFERENCES books(id), " +
            "  member_id TEXT, " +
            "  issue_date TEXT NOT NULL, " +
            "  due_date TEXT NOT NULL, " +
            "  status TEXT NOT NULL, " +
            "  late_fee REAL DEFAULT 0.0" +
            ");";

        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(schema);
            System.out.println("Relational schema verified.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Example Check-in with Late Fee Penalty Calculation
    public static double returnBook(String loanId, String returnDate, double dailyRate) throws SQLException {
        String selectSql = "SELECT due_date, book_id, member_id FROM loan_transactions WHERE id = ?";
        String updateLoan = "UPDATE loan_transactions SET status = 'Returned', return_date = ?, late_fee = ? WHERE id = ?";
        String updateBook = "UPDATE books SET available_copies = available_copies + 1 WHERE id = ?";
        String updateMember = "UPDATE members SET current_borrowed = current_borrowed - 1, unpaid_fines = unpaid_fines + ? WHERE id = ?";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(selectSql)) {
                ps.setString(1, loanId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    String dueDate = rs.getString("due_date");
                    long daysOverdue = java.time.temporal.ChronoUnit.DAYS.between(
                        java.time.LocalDate.parse(dueDate),
                        java.time.LocalDate.parse(returnDate)
                    );
                    double fine = (daysOverdue > 0) ? daysOverdue * dailyRate : 0.0;

                    try (PreparedStatement loanPs = conn.prepareStatement(updateLoan);
                         PreparedStatement bookPs = conn.prepareStatement(updateBook);
                         PreparedStatement memberPs = conn.prepareStatement(updateMember)) {
                        
                        loanPs.setString(1, returnDate);
                        loanPs.setDouble(2, fine);
                        loanPs.setString(3, loanId);
                        loanPs.executeUpdate();

                        bookPs.setString(1, rs.getString("book_id"));
                        bookPs.executeUpdate();

                        memberPs.setDouble(1, fine);
                        memberPs.setString(2, rs.getString("member_id"));
                        memberPs.executeUpdate();

                        conn.commit();
                        return fine;
                    }
                }
            }
        }
        return 0.0;
    }
}`;

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 lg:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] px-2 py-0.5 border border-[#1A1A1A] bg-[#1A1A1A] text-[#FDFCF8] font-bold">
              JDBC &amp; SQL ENGINE
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60">
              ANSI Relational Standard
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black italic font-serif-display text-[#1A1A1A]">
            SQLite &amp; MySQL Relational Schema
          </h2>
          <p className="text-xs font-sans text-[#1A1A1A]/70 max-w-xl leading-relaxed">
            Data Definition Language (DDL), Foreign Key Constraints, Java JDBC DAO Implementation, and Portable .SQL Database Dump.
          </p>
        </div>

        <div className="flex items-center gap-3 self-end md:self-auto shrink-0">
          <button
            onClick={handleCopySql}
            className="px-4 py-2 bg-transparent hover:bg-[#1A1A1A] hover:text-[#FDFCF8] text-[#1A1A1A] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy DDL'}
          </button>
          <button
            id="download-sql-dump-btn"
            onClick={handleDownloadSql}
            className="px-4 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" /> Export .SQL Dump
          </button>
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8]">
        <div className="flex border-b border-[#1A1A1A] overflow-x-auto text-xs font-sans uppercase tracking-wider">
          <button
            onClick={() => setActiveSubTab('tables')}
            className={`px-6 py-3.5 border-r border-[#1A1A1A] transition-colors flex items-center gap-2 ${
              activeSubTab === 'tables'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <Table className="w-3.5 h-3.5" /> Relational Tables Explorer
          </button>
          <button
            onClick={() => setActiveSubTab('query')}
            className={`px-6 py-3.5 border-r border-[#1A1A1A] transition-colors flex items-center gap-2 ${
              activeSubTab === 'query'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" /> SQL Query Runner
          </button>
          <button
            onClick={() => setActiveSubTab('schema')}
            className={`px-6 py-3.5 border-r border-[#1A1A1A] transition-colors flex items-center gap-2 ${
              activeSubTab === 'schema'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" /> SQL DDL Dump
          </button>
          <button
            onClick={() => setActiveSubTab('jdbc')}
            className={`px-6 py-3.5 transition-colors flex items-center gap-2 ${
              activeSubTab === 'jdbc'
                ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" /> Java (JDBC) Architecture
          </button>
        </div>

        {/* Sub-tab Content */}
        <div className="p-6">
          {/* RELATIONAL TABLES EXPLORER */}
          {activeSubTab === 'tables' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60">Select Entity:</span>
                <button
                  onClick={() => setSelectedTable('books')}
                  className={`px-3 py-1 text-xs font-sans uppercase tracking-wider border ${
                    selectedTable === 'books'
                      ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A] font-bold'
                      : 'bg-transparent text-[#1A1A1A] border-[#1A1A1A]/30'
                  }`}
                >
                  books ({books.length})
                </button>
                <button
                  onClick={() => setSelectedTable('members')}
                  className={`px-3 py-1 text-xs font-sans uppercase tracking-wider border ${
                    selectedTable === 'members'
                      ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A] font-bold'
                      : 'bg-transparent text-[#1A1A1A] border-[#1A1A1A]/30'
                  }`}
                >
                  members ({members.length})
                </button>
                <button
                  onClick={() => setSelectedTable('loans')}
                  className={`px-3 py-1 text-xs font-sans uppercase tracking-wider border ${
                    selectedTable === 'loans'
                      ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A] font-bold'
                      : 'bg-transparent text-[#1A1A1A] border-[#1A1A1A]/30'
                  }`}
                >
                  loan_transactions ({loans.length})
                </button>
              </div>

              <div className="border border-[#1A1A1A] overflow-x-auto text-xs">
                {selectedTable === 'books' && (
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#1A1A1A]/5 text-[10px] font-mono text-[#1A1A1A] border-b border-[#1A1A1A]">
                      <tr>
                        <th className="px-4 py-2.5">id</th>
                        <th className="px-4 py-2.5">isbn</th>
                        <th className="px-4 py-2.5">title</th>
                        <th className="px-4 py-2.5">category</th>
                        <th className="px-4 py-2.5">total_copies</th>
                        <th className="px-4 py-2.5">available_copies</th>
                        <th className="px-4 py-2.5">shelf_location</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1A1A1A]/15 font-mono text-[11px]">
                      {books.map(b => (
                        <tr key={b.id} className="hover:bg-[#1A1A1A]/5">
                          <td className="px-4 py-2 text-[#1A1A1A]/60">{b.id}</td>
                          <td className="px-4 py-2 font-bold text-[#1A1A1A]">{b.isbn}</td>
                          <td className="px-4 py-2 text-[#1A1A1A] italic">{b.title}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]/70">{b.category}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]">{b.totalCopies}</td>
                          <td className="px-4 py-2 font-bold text-emerald-800">{b.availableCopies}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]/70">{b.shelfLocation}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {selectedTable === 'members' && (
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#1A1A1A]/5 text-[10px] font-mono text-[#1A1A1A] border-b border-[#1A1A1A]">
                      <tr>
                        <th className="px-4 py-2.5">id</th>
                        <th className="px-4 py-2.5">member_code</th>
                        <th className="px-4 py-2.5">name</th>
                        <th className="px-4 py-2.5">role</th>
                        <th className="px-4 py-2.5">email</th>
                        <th className="px-4 py-2.5">borrowed</th>
                        <th className="px-4 py-2.5">unpaid_fines</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1A1A1A]/15 font-mono text-[11px]">
                      {members.map(m => (
                        <tr key={m.id} className="hover:bg-[#1A1A1A]/5">
                          <td className="px-4 py-2 text-[#1A1A1A]/60">{m.id}</td>
                          <td className="px-4 py-2 font-bold text-[#1A1A1A]">{m.memberCode}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]">{m.name}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]/70">{m.role}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]/60">{m.email}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]">{m.currentBorrowedCount}</td>
                          <td className="px-4 py-2 font-bold text-red-700">${m.unpaidFines.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {selectedTable === 'loans' && (
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#1A1A1A]/5 text-[10px] font-mono text-[#1A1A1A] border-b border-[#1A1A1A]">
                      <tr>
                        <th className="px-4 py-2.5">id</th>
                        <th className="px-4 py-2.5">book_title</th>
                        <th className="px-4 py-2.5">member_name</th>
                        <th className="px-4 py-2.5">issue_date</th>
                        <th className="px-4 py-2.5">due_date</th>
                        <th className="px-4 py-2.5">status</th>
                        <th className="px-4 py-2.5">late_fee</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1A1A1A]/15 font-mono text-[11px]">
                      {loans.map(l => (
                        <tr key={l.id} className="hover:bg-[#1A1A1A]/5">
                          <td className="px-4 py-2 text-[#1A1A1A]/60">{l.id}</td>
                          <td className="px-4 py-2 text-[#1A1A1A] italic">{l.bookTitle}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]">{l.memberName}</td>
                          <td className="px-4 py-2 text-[#1A1A1A]/60">{l.issueDate}</td>
                          <td className="px-4 py-2 font-bold text-[#1A1A1A]">{l.dueDate}</td>
                          <td className="px-4 py-2">
                            <span className={l.status === 'Overdue' ? 'text-red-700 font-bold' : 'text-[#1A1A1A]'}>
                              {l.status}
                            </span>
                          </td>
                          <td className="px-4 py-2 font-bold text-[#1A1A1A]">${l.lateFee.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}

          {/* SQL QUERY RUNNER */}
          {activeSubTab === 'query' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
                    Interactive SQL Query Console
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setCustomSql("SELECT book_title, member_name, due_date, status, late_fee FROM loan_transactions WHERE status = 'Overdue';")}
                      className="text-[10px] uppercase font-sans tracking-wider border border-[#1A1A1A]/30 px-2 py-0.5 hover:border-[#1A1A1A]"
                    >
                      Overdue Query
                    </button>
                    <button
                      onClick={() => setCustomSql("SELECT isbn, title, author, available_copies, shelf_location FROM books WHERE available_copies > 0;")}
                      className="text-[10px] uppercase font-sans tracking-wider border border-[#1A1A1A]/30 px-2 py-0.5 hover:border-[#1A1A1A]"
                    >
                      Available Books
                    </button>
                  </div>
                </div>

                <textarea
                  value={customSql}
                  onChange={(e) => setCustomSql(e.target.value)}
                  rows={3}
                  className="w-full p-3 font-mono text-xs bg-[#1A1A1A] text-[#FDFCF8] border border-[#1A1A1A] focus:outline-hidden"
                />

                <div className="flex justify-end">
                  <button
                    onClick={handleExecuteQuery}
                    className="px-4 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5" /> Execute Statement
                  </button>
                </div>
              </div>

              {queryResult && (
                <div className="border border-[#1A1A1A] overflow-x-auto text-xs">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-[#1A1A1A]/5 text-[10px] font-mono text-[#1A1A1A] border-b border-[#1A1A1A]">
                      <tr>
                        {Object.keys(queryResult[0] || {}).map((k) => (
                          <th key={k} className="px-4 py-2 font-normal uppercase">{k}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1A1A1A]/15 font-mono text-[11px]">
                      {queryResult.map((row, idx) => (
                        <tr key={idx} className="hover:bg-[#1A1A1A]/5">
                          {Object.values(row).map((val: any, i) => (
                            <td key={i} className="px-4 py-2 text-[#1A1A1A]">
                              {String(val)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* DDL SCHEMA */}
          {activeSubTab === 'schema' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
                  Full Database Dump (ANSI SQL)
                </span>
                <button
                  onClick={handleCopySql}
                  className="px-3 py-1 border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-wider hover:bg-[#1A1A1A] hover:text-[#FDFCF8] transition-colors"
                >
                  {copied ? 'Copied to Clipboard' : 'Copy All SQL'}
                </button>
              </div>
              <pre className="p-4 bg-[#1A1A1A] text-[#FDFCF8] text-xs font-mono overflow-x-auto max-h-[500px] border border-[#1A1A1A] leading-relaxed">
                {sqlDump}
              </pre>
            </div>
          )}

          {/* JAVA JDBC ARCHITECTURE */}
          {activeSubTab === 'jdbc' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
                  Java (Swing/JavaFX) JDBC DAO Architecture
                </span>
                <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60">
                  SQLite / MySQL Connector
                </span>
              </div>
              <pre className="p-4 bg-[#1A1A1A] text-[#FDFCF8] text-xs font-mono overflow-x-auto max-h-[500px] border border-[#1A1A1A] leading-relaxed">
                {sampleJdbcCode}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
