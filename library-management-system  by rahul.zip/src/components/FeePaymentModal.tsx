import React, { useState } from 'react';
import { X, DollarSign, CheckCircle2, Receipt, ShieldAlert } from 'lucide-react';
import { Member, SystemSettings, LateFeePayment } from '../types';
import { formatCurrency } from '../utils/lateFeeCalculator';

interface FeePaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  member: Member | null;
  settings: SystemSettings;
  onConfirmPayment: (
    memberId: string,
    amount: number,
    method: 'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived',
    notes?: string
  ) => void;
}

export const FeePaymentModal: React.FC<FeePaymentModalProps> = ({
  isOpen,
  onClose,
  member,
  settings,
  onConfirmPayment,
}) => {
  const [payAmount, setPayAmount] = useState<number>(member?.unpaidFines || 0);
  const [method, setMethod] = useState<'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived'>('Cash');
  const [notes, setNotes] = useState('');

  if (!isOpen || !member) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (payAmount <= 0) return;

    onConfirmPayment(member.id, payAmount, method, notes.trim() || undefined);
    onClose();
  };

  return (
    <div id="fee-payment-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Financial Settlement
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Settle Library Fine
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-4 border border-[#1A1A1A] bg-[#1A1A1A]/5 space-y-1.5 text-xs font-sans">
            <div className="flex justify-between">
              <span className="text-[#1A1A1A]/60">Patron Name:</span>
              <span className="font-bold text-[#1A1A1A]">{member.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#1A1A1A]/60">Member Barcode ID:</span>
              <span className="font-mono text-[#1A1A1A]">{member.memberCode}</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-[#1A1A1A]/20">
              <span className="text-[#1A1A1A]/60">Outstanding Fines:</span>
              <span className="font-black italic font-serif-display text-base text-red-700">
                {formatCurrency(member.unpaidFines, settings.currencySymbol)}
              </span>
            </div>
          </div>

          <div>
            <label htmlFor="pay-amount-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Payment Tender ({settings.currencySymbol})
            </label>
            <input
              id="pay-amount-input"
              type="number"
              step="0.25"
              min="0.25"
              max={member.unpaidFines}
              value={payAmount}
              onChange={(e) => setPayAmount(Number(e.target.value))}
              required
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-bold font-mono focus:outline-hidden"
            />
            <div className="flex justify-end gap-2 mt-1">
              <button
                type="button"
                onClick={() => setPayAmount(member.unpaidFines)}
                className="text-[10px] font-sans uppercase font-bold tracking-wider text-[#1A1A1A] hover:underline"
              >
                Clear Full Balance ({formatCurrency(member.unpaidFines, settings.currencySymbol)})
              </button>
            </div>
          </div>

          <div>
            <label htmlFor="pay-method-select" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Payment Channel
            </label>
            <select
              id="pay-method-select"
              value={method}
              onChange={(e) => setMethod(e.target.value as any)}
              className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
            >
              <option value="Cash">Cash at Circulation Desk</option>
              <option value="Credit Card">Credit / Debit Card</option>
              <option value="Campus Pay">Campus Card / University ID</option>
              <option value="Waived">Waive Fine (Administrative Exemption)</option>
            </select>
          </div>

          <div>
            <label htmlFor="pay-notes-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Receipt Remarks / Waiver Justification
            </label>
            <input
              id="pay-notes-input"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Cleared for graduation audit"
              className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
            >
              Cancel
            </button>
            <button
              id="confirm-pay-fine-btn"
              type="submit"
              className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest transition-colors shadow-2xs"
            >
              {method === 'Waived' ? 'Confirm Waiver' : 'Process Receipt'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
