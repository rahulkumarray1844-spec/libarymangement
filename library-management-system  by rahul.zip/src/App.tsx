import React, { useState, useEffect, useMemo } from 'react';
import {
  getStoredBooks,
  saveBooks,
  getStoredMembers,
  saveMembers,
  getStoredLoans,
  saveLoans,
  getStoredPayments,
  savePayments,
  getStoredEmailLogs,
  saveEmailLogs,
  getStoredSettings,
  saveSettings,
  resetToSampleData,
} from './utils/storage';
import {
  Book,
  Member,
  LoanTransaction,
  LateFeePayment,
  EmailReminder,
  SystemSettings,
} from './types';
import { computeLateFee, calculateOverdueDays, formatCurrency } from './utils/lateFeeCalculator';

// Components
import { Navigation, ActiveTab } from './components/Navigation';
import { InventoryView } from './components/InventoryView';
import { CirculationView } from './components/CirculationView';
import { MembersView } from './components/MembersView';
import { LateFeesView } from './components/LateFeesView';
import { OverdueRemindersView } from './components/OverdueRemindersView';
import { DatabaseSqlView } from './components/DatabaseSqlView';

// Modals
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { IssueBookModal } from './components/IssueBookModal';
import { ReturnBookModal } from './components/ReturnBookModal';
import { BookFormModal } from './components/BookFormModal';
import { MemberFormModal } from './components/MemberFormModal';
import { FeePaymentModal } from './components/FeePaymentModal';
import { EmailReminderModal } from './components/EmailReminderModal';
import { BarcodeLabelModal } from './components/BarcodeLabelModal';
import { MemberCardModal } from './components/MemberCardModal';
import { SettingsModal } from './components/SettingsModal';

import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export default function App() {
  // Primary State
  const [books, setBooks] = useState<Book[]>(getStoredBooks);
  const [members, setMembers] = useState<Member[]>(getStoredMembers);
  const [loans, setLoans] = useState<LoanTransaction[]>(getStoredLoans);
  const [payments, setPayments] = useState<LateFeePayment[]>(getStoredPayments);
  const [emailLogs, setEmailLogs] = useState<EmailReminder[]>(getStoredEmailLogs);
  const [settings, setSettings] = useState<SystemSettings>(getStoredSettings);

  // Active View & Filters
  const [activeTab, setActiveTab] = useState<ActiveTab>('inventory');
  const [searchQuery, setSearchQuery] = useState('');

  // Toast notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(prev => (prev?.message === message ? null : prev));
    }, 4500);
  };

  // Modals state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [issuePreselectedBook, setIssuePreselectedBook] = useState<Book | null>(null);
  const [issuePreselectedMember, setIssuePreselectedMember] = useState<Member | null>(null);

  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [returnPreselectedLoan, setReturnPreselectedLoan] = useState<LoanTransaction | null>(null);

  const [isBookFormOpen, setIsBookFormOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  const [isMemberFormOpen, setIsMemberFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);

  const [isFeePaymentOpen, setIsFeePaymentOpen] = useState(false);
  const [feePaymentMember, setFeePaymentMember] = useState<Member | null>(null);

  const [isEmailReminderOpen, setIsEmailReminderOpen] = useState(false);
  const [reminderLoan, setReminderLoan] = useState<LoanTransaction | null>(null);

  const [isBarcodeLabelOpen, setIsBarcodeLabelOpen] = useState(false);
  const [labelBook, setLabelBook] = useState<Book | null>(null);

  const [isMemberCardOpen, setIsMemberCardOpen] = useState(false);
  const [cardMember, setCardMember] = useState<Member | null>(null);

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Auto-audit overdue loans on mount and when settings change
  useEffect(() => {
    let hasChanges = false;
    const updatedLoans = loans.map(l => {
      if (l.status === 'Active') {
        const overdueDays = calculateOverdueDays(l.dueDate);
        if (overdueDays > 0) {
          hasChanges = true;
          const feeCalc = computeLateFee(l.dueDate, settings);
          return {
            ...l,
            status: 'Overdue' as const,
            lateFee: feeCalc.fee,
          };
        }
      } else if (l.status === 'Overdue') {
        const feeCalc = computeLateFee(l.dueDate, settings);
        if (feeCalc.fee !== l.lateFee) {
          hasChanges = true;
          return {
            ...l,
            lateFee: feeCalc.fee,
          };
        }
      }
      return l;
    });

    if (hasChanges) {
      setLoans(updatedLoans);
      saveLoans(updatedLoans);
    }
  }, [settings]);

  // Derived counts
  const overdueCount = useMemo(() => {
    return loans.filter(l => l.status === 'Overdue').length;
  }, [loans]);

  const unpaidFinesTotal = useMemo(() => {
    return members.reduce((sum, m) => sum + m.unpaidFines, 0);
  }, [members]);

  // ----------------------------------------------------
  // Handlers
  // ----------------------------------------------------

  // 1. Issue Book
  const handleConfirmIssue = (newLoanData: Omit<LoanTransaction, 'id'>) => {
    const loanId = `loan-${Date.now()}`;
    const newLoan: LoanTransaction = {
      ...newLoanData,
      id: loanId,
    };

    // Update book copies
    const updatedBooks = books.map(b =>
      b.id === newLoan.bookId
        ? { ...b, availableCopies: Math.max(0, b.availableCopies - 1) }
        : b
    );
    setBooks(updatedBooks);
    saveBooks(updatedBooks);

    // Update member borrow count
    const updatedMembers = members.map(m =>
      m.id === newLoan.memberId
        ? { ...m, currentBorrowedCount: m.currentBorrowedCount + 1 }
        : m
    );
    setMembers(updatedMembers);
    saveMembers(updatedMembers);

    // Add loan
    const updatedLoans = [newLoan, ...loans];
    setLoans(updatedLoans);
    saveLoans(updatedLoans);

    showToast(`Checked out "${newLoan.bookTitle}" to ${newLoan.memberName} successfully!`);
  };

  // 2. Return Book
  const handleConfirmReturn = (
    loanId: string,
    returnDate: string,
    fineAmount: number,
    paymentOption: 'pay_now' | 'defer' | 'waive',
    paymentMethod: 'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived',
    waiverReason?: string
  ) => {
    const loan = loans.find(l => l.id === loanId);
    if (!loan) return;

    // Restore book availability
    const updatedBooks = books.map(b =>
      b.id === loan.bookId
        ? { ...b, availableCopies: Math.min(b.totalCopies, b.availableCopies + 1) }
        : b
    );
    setBooks(updatedBooks);
    saveBooks(updatedBooks);

    // Update member borrow count and fines if deferred
    const updatedMembers = members.map(m => {
      if (m.id === loan.memberId) {
        const newBorrowed = Math.max(0, m.currentBorrowedCount - 1);
        const newFines = paymentOption === 'defer' ? m.unpaidFines + fineAmount : m.unpaidFines;
        return {
          ...m,
          currentBorrowedCount: newBorrowed,
          unpaidFines: Number(newFines.toFixed(2)),
        };
      }
      return m;
    });
    setMembers(updatedMembers);
    saveMembers(updatedMembers);

    // Record payment receipt if paid now or waived
    if (fineAmount > 0 && (paymentOption === 'pay_now' || paymentOption === 'waive')) {
      const newPayment: LateFeePayment = {
        id: `pay-${Date.now()}`,
        loanId: loan.id,
        memberId: loan.memberId,
        memberName: loan.memberName,
        bookTitle: loan.bookTitle,
        amount: fineAmount,
        paymentDate: returnDate,
        method: paymentMethod,
        receiptNumber: `REC-${Date.now().toString().slice(-6)}`,
        notes: waiverReason || (paymentOption === 'waive' ? 'Waived upon check-in' : 'Paid at check-in'),
      };
      const updatedPayments = [newPayment, ...payments];
      setPayments(updatedPayments);
      savePayments(updatedPayments);
    }

    // Mark loan as Returned
    const updatedLoans = loans.map(l =>
      l.id === loanId
        ? {
            ...l,
            returnDate,
            status: 'Returned' as const,
            lateFee: fineAmount,
            lateFeePaid: paymentOption === 'pay_now' || paymentOption === 'waive',
          }
        : l
    );
    setLoans(updatedLoans);
    saveLoans(updatedLoans);

    showToast(`"${loan.bookTitle}" successfully returned to circulation.`);
  };

  // 3. Renew Loan
  const handleRenewLoan = (loanId: string) => {
    const loan = loans.find(l => l.id === loanId);
    if (!loan || loan.renewalCount >= loan.maxRenewals) return;

    const currentDue = new Date(loan.dueDate);
    currentDue.setDate(currentDue.getDate() + settings.standardLoanDays);
    const newDueDate = currentDue.toISOString().split('T')[0];

    const updatedLoans = loans.map(l =>
      l.id === loanId
        ? {
            ...l,
            dueDate: newDueDate,
            renewalCount: l.renewalCount + 1,
            status: 'Active' as const,
            lateFee: 0,
          }
        : l
    );
    setLoans(updatedLoans);
    saveLoans(updatedLoans);

    showToast(`Loan renewed for 14 days! New due date: ${newDueDate}`);
  };

  // 4. Send Individual Overdue Reminder Email
  const handleConfirmSendReminder = (
    targetLoan: LoanTransaction,
    subject: string,
    body: string
  ) => {
    const feeData = computeLateFee(targetLoan.dueDate, settings);
    const newLog: EmailReminder = {
      id: `eml-${Date.now()}`,
      loanId: targetLoan.id,
      memberId: targetLoan.memberId,
      memberEmail: targetLoan.memberEmail,
      memberName: targetLoan.memberName,
      bookTitle: targetLoan.bookTitle,
      dueDate: targetLoan.dueDate,
      daysOverdue: feeData.overdueDays,
      fineAmount: feeData.fee,
      sentAt: new Date().toISOString(),
      status: 'Delivered',
      subject,
      bodySnippet: body.slice(0, 150) + '...',
    };

    const updatedLogs = [newLog, ...emailLogs];
    setEmailLogs(updatedLogs);
    saveEmailLogs(updatedLogs);

    // Update loan reminder count
    const updatedLoans = loans.map(l =>
      l.id === targetLoan.id
        ? {
            ...l,
            remindersSentCount: l.remindersSentCount + 1,
            lastReminderSentDate: new Date().toISOString().split('T')[0],
          }
        : l
    );
    setLoans(updatedLoans);
    saveLoans(updatedLoans);

    showToast(`Automated reminder email sent to ${targetLoan.memberEmail}!`);
  };

  // 5. Batch Dispatch Overdue Reminders
  const handleSendBatchReminders = (overdueList: LoanTransaction[]) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const newLogs: EmailReminder[] = [];

    overdueList.forEach(l => {
      const feeData = computeLateFee(l.dueDate, settings);
      newLogs.push({
        id: `eml-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        loanId: l.id,
        memberId: l.memberId,
        memberEmail: l.memberEmail,
        memberName: l.memberName,
        bookTitle: l.bookTitle,
        dueDate: l.dueDate,
        daysOverdue: feeData.overdueDays,
        fineAmount: feeData.fee,
        sentAt: new Date().toISOString(),
        status: 'Delivered',
        subject: `[BATCH NOTICE] Overdue Library Item: "${l.bookTitle}"`,
        bodySnippet: `Automated notice dispatched for ${feeData.overdueDays} days overdue item with ${formatCurrency(feeData.fee, settings.currencySymbol)} accrued fee.`,
      });
    });

    const updatedLogs = [...newLogs, ...emailLogs];
    setEmailLogs(updatedLogs);
    saveEmailLogs(updatedLogs);

    // Update all overdue loans reminder counts
    const updatedLoans = loans.map(l => {
      if (overdueList.some(ol => ol.id === l.id)) {
        return {
          ...l,
          remindersSentCount: l.remindersSentCount + 1,
          lastReminderSentDate: todayStr,
        };
      }
      return l;
    });
    setLoans(updatedLoans);
    saveLoans(updatedLoans);

    showToast(`Batch automated notices dispatched to ${overdueList.length} patron inboxes!`);
  };

  // 6. Save Book (Catalog new / Edit existing)
  const handleSaveBook = (bookData: Omit<Book, 'id'>, existingId?: string) => {
    if (existingId) {
      const updated = books.map(b => (b.id === existingId ? { ...bookData, id: existingId } : b));
      setBooks(updated);
      saveBooks(updated);
      showToast(`Updated "${bookData.title}" in inventory.`);
    } else {
      const newBook: Book = {
        ...bookData,
        id: `b-${Date.now()}`,
      };
      const updated = [newBook, ...books];
      setBooks(updated);
      saveBooks(updated);
      showToast(`Cataloged "${newBook.title}" with barcode ISBN ${newBook.isbn}!`);
    }
  };

  // 7. Delete Book
  const handleDeleteBook = (bookId: string) => {
    const hasActiveLoan = loans.some(l => l.bookId === bookId && l.status !== 'Returned');
    if (hasActiveLoan) {
      showToast('Cannot delete book while active loans exist for this title.', 'error');
      return;
    }
    const updated = books.filter(b => b.id !== bookId);
    setBooks(updated);
    saveBooks(updated);
    showToast('Book removed from library catalog.');
  };

  // 8. Save Member
  const handleSaveMember = (memberData: Omit<Member, 'id'>, existingId?: string) => {
    if (existingId) {
      const updated = members.map(m => (m.id === existingId ? { ...memberData, id: existingId } : m));
      setMembers(updated);
      saveMembers(updated);
      showToast(`Updated profile for ${memberData.name}.`);
    } else {
      const newMember: Member = {
        ...memberData,
        id: `m-${Date.now()}`,
      };
      const updated = [newMember, ...members];
      setMembers(updated);
      saveMembers(updated);
      showToast(`Registered patron ${newMember.name} (Code: ${newMember.memberCode})!`);
    }
  };

  // 9. Process Late Fee Payment
  const handleConfirmFeePayment = (
    memberId: string,
    amount: number,
    method: 'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived',
    notes?: string
  ) => {
    const member = members.find(m => m.id === memberId);
    if (!member) return;

    const receiptNum = `REC-${Date.now().toString().slice(-6)}`;
    const newPayment: LateFeePayment = {
      id: `pay-${Date.now()}`,
      loanId: 'account-settlement',
      memberId: member.id,
      memberName: member.name,
      bookTitle: 'Patron Account Fine Balance',
      amount,
      paymentDate: new Date().toISOString().split('T')[0],
      method,
      receiptNumber: receiptNum,
      notes,
    };

    const updatedPayments = [newPayment, ...payments];
    setPayments(updatedPayments);
    savePayments(updatedPayments);

    // Update member unpaid debt
    const updatedMembers = members.map(m =>
      m.id === memberId
        ? { ...m, unpaidFines: Math.max(0, Number((m.unpaidFines - amount).toFixed(2))) }
        : m
    );
    setMembers(updatedMembers);
    saveMembers(updatedMembers);

    showToast(
      method === 'Waived'
        ? `Waived ${formatCurrency(amount, settings.currencySymbol)} for ${member.name}.`
        : `Processed payment of ${formatCurrency(amount, settings.currencySymbol)} (Receipt #${receiptNum}).`
    );
  };

  // 10. Save Settings
  const handleSaveSettings = (newSettings: SystemSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    showToast('Library policy & fee rates updated.');
  };

  // 11. Reset to Default Sample Data
  const handleResetData = () => {
    if (window.confirm('Reset all library data back to default course seed records?')) {
      resetToSampleData();
      setBooks(getStoredBooks());
      setMembers(getStoredMembers());
      setLoans(getStoredLoans());
      setPayments(getStoredPayments());
      setEmailLogs(getStoredEmailLogs());
      setSettings(getStoredSettings());
      showToast('Library database reset to default sample dataset.');
    }
  };

  // Barcode Scanner Action Handler
  const handleBarcodeScanned = (code: string) => {
    // Check if matching book ISBN or member
    const book = books.find(b => b.isbn === code || b.id === code);
    const member = members.find(m => m.memberCode === code || m.id === code);

    if (book) {
      showToast(`Scanned Book: "${book.title}" (${book.availableCopies} available)`, 'info');
    } else if (member) {
      showToast(`Scanned Patron: ${member.name} (${member.role})`, 'info');
    } else {
      showToast(`Unrecognized barcode: ${code}`, 'info');
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCF8] text-[#1A1A1A] flex flex-col font-sans selection:bg-[#1A1A1A] selection:text-[#FDFCF8]">
      {/* Toast Notification Banner */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3.5 bg-[#1A1A1A] text-[#FDFCF8] border border-[#1A1A1A] shadow-2xl animate-in fade-in slide-in-from-bottom-4 text-xs font-sans tracking-wider">
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
          {toast.type === 'info' && <Info className="w-4 h-4 text-[#FDFCF8] shrink-0" />}
          <span className="font-medium">{toast.message}</span>
          <button
            onClick={() => setToast(null)}
            className="p-1 text-[#FDFCF8]/60 hover:text-white rounded ml-2"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Header & Navigation */}
      <Navigation
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        settings={settings}
        overdueCount={overdueCount}
        unpaidFinesTotal={unpaidFinesTotal}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenIssueModal={() => {
          setIssuePreselectedBook(null);
          setIssuePreselectedMember(null);
          setIsIssueModalOpen(true);
        }}
        onOpenReturnModal={() => {
          setReturnPreselectedLoan(null);
          setIsReturnModalOpen(true);
        }}
        onResetData={handleResetData}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'inventory' && (
          <InventoryView
            books={books}
            searchQuery={searchQuery}
            onAddNewBook={() => {
              setEditingBook(null);
              setIsBookFormOpen(true);
            }}
            onEditBook={(book) => {
              setEditingBook(book);
              setIsBookFormOpen(true);
            }}
            onDeleteBook={handleDeleteBook}
            onPrintBarcode={(book) => {
              setLabelBook(book);
              setIsBarcodeLabelOpen(true);
            }}
            onIssueBook={(book) => {
              setIssuePreselectedBook(book);
              setIsIssueModalOpen(true);
            }}
          />
        )}

        {activeTab === 'circulation' && (
          <CirculationView
            loans={loans}
            settings={settings}
            searchQuery={searchQuery}
            onOpenIssueModal={() => {
              setIssuePreselectedBook(null);
              setIsIssueModalOpen(true);
            }}
            onOpenReturnModal={(loan) => {
              setReturnPreselectedLoan(loan || null);
              setIsReturnModalOpen(true);
            }}
            onRenewLoan={handleRenewLoan}
            onSendReminder={(loan) => {
              setReminderLoan(loan);
              setIsEmailReminderOpen(true);
            }}
          />
        )}

        {activeTab === 'members' && (
          <MembersView
            members={members}
            settings={settings}
            searchQuery={searchQuery}
            onAddNewMember={() => {
              setEditingMember(null);
              setIsMemberFormOpen(true);
            }}
            onEditMember={(member) => {
              setEditingMember(member);
              setIsMemberFormOpen(true);
            }}
            onOpenCardModal={(member) => {
              setCardMember(member);
              setIsMemberCardOpen(true);
            }}
            onPayFines={(member) => {
              setFeePaymentMember(member);
              setIsFeePaymentOpen(true);
            }}
            onIssueToMember={(member) => {
              setIssuePreselectedMember(member);
              setIsIssueModalOpen(true);
            }}
          />
        )}

        {activeTab === 'late_fees' && (
          <LateFeesView
            payments={payments}
            members={members}
            loans={loans}
            settings={settings}
            onPayFines={(member) => {
              setFeePaymentMember(member);
              setIsFeePaymentOpen(true);
            }}
            onOpenSettings={() => setIsSettingsOpen(true)}
          />
        )}

        {activeTab === 'reminders' && (
          <OverdueRemindersView
            loans={loans}
            emailLogs={emailLogs}
            settings={settings}
            onSendSingleReminder={(loan) => {
              setReminderLoan(loan);
              setIsEmailReminderOpen(true);
            }}
            onSendBatchReminders={handleSendBatchReminders}
          />
        )}

        {activeTab === 'database' && (
          <DatabaseSqlView
            books={books}
            members={members}
            loans={loans}
            settings={settings}
          />
        )}
      </main>

      {/* Editorial Colophon / Footer */}
      <footer className="bg-[#FDFCF8] border-t border-[#1A1A1A] py-8 text-xs font-sans text-[#1A1A1A]/70 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 text-center sm:text-left">
            <span className="font-bold text-[#1A1A1A] uppercase tracking-wider">{settings.libraryName}</span>
            <span>—</span>
            <span className="italic font-serif">Catalog, Circulation, &amp; Relational Repository</span>
          </div>
          <div className="flex items-center space-x-4 text-[10px] uppercase tracking-widest text-[#1A1A1A]/60">
            <span>Barcode &amp; RFID Certified</span>
            <span>·</span>
            <span>Automated Overdue Engine</span>
            <span>·</span>
            <span>Java JDBC SQLite/MySQL</span>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      {/* 1. Barcode & Camera Scanner */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScanResult={handleBarcodeScanned}
        books={books}
        members={members}
        onSelectBookForIssue={(book) => {
          setIssuePreselectedBook(book);
          setIsIssueModalOpen(true);
        }}
        onSelectBookForReturn={(book) => {
          const activeLoan = loans.find(l => l.bookId === book.id && (l.status === 'Active' || l.status === 'Overdue'));
          if (activeLoan) {
            setReturnPreselectedLoan(activeLoan);
            setIsReturnModalOpen(true);
          } else {
            showToast(`No active loan found for "${book.title}". It is already available on shelf.`, 'info');
          }
        }}
        onSelectMember={(member) => {
          setIssuePreselectedMember(member);
          setIsIssueModalOpen(true);
        }}
      />

      {/* 2. Issue Book Modal */}
      <IssueBookModal
        isOpen={isIssueModalOpen}
        onClose={() => setIsIssueModalOpen(false)}
        books={books}
        members={members}
        settings={settings}
        preselectedBook={issuePreselectedBook}
        preselectedMember={issuePreselectedMember}
        onConfirmIssue={handleConfirmIssue}
      />

      {/* 3. Return Book Modal */}
      <ReturnBookModal
        isOpen={isReturnModalOpen}
        onClose={() => setIsReturnModalOpen(false)}
        loans={loans}
        settings={settings}
        preselectedLoan={returnPreselectedLoan}
        onConfirmReturn={handleConfirmReturn}
      />

      {/* 4. Book Catalog Form Modal */}
      <BookFormModal
        isOpen={isBookFormOpen}
        onClose={() => setIsBookFormOpen(false)}
        onSaveBook={handleSaveBook}
        editingBook={editingBook}
      />

      {/* 5. Member Form Modal */}
      <MemberFormModal
        isOpen={isMemberFormOpen}
        onClose={() => setIsMemberFormOpen(false)}
        onSaveMember={handleSaveMember}
        editingMember={editingMember}
      />

      {/* 6. Late Fee Settlement Modal */}
      <FeePaymentModal
        isOpen={isFeePaymentOpen}
        onClose={() => setIsFeePaymentOpen(false)}
        member={feePaymentMember}
        settings={settings}
        onConfirmPayment={handleConfirmFeePayment}
      />

      {/* 7. Email Reminder Modal */}
      <EmailReminderModal
        isOpen={isEmailReminderOpen}
        onClose={() => setIsEmailReminderOpen(false)}
        loan={reminderLoan}
        settings={settings}
        onConfirmSend={handleConfirmSendReminder}
      />

      {/* 8. Book Spine Barcode Print Label Modal */}
      <BarcodeLabelModal
        isOpen={isBarcodeLabelOpen}
        onClose={() => setIsBarcodeLabelOpen(false)}
        book={labelBook}
      />

      {/* 9. Member Digital Library Pass Modal */}
      <MemberCardModal
        isOpen={isMemberCardOpen}
        onClose={() => setIsMemberCardOpen(false)}
        member={cardMember}
      />

      {/* 10. System & Policy Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
      />
    </div>
  );
}
