import React, { useState, useEffect } from 'react';
import { X, Sliders, Save, ShieldCheck } from 'lucide-react';
import { SystemSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SystemSettings;
  onSaveSettings: (newSettings: SystemSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<SystemSettings>(settings);

  useEffect(() => {
    if (isOpen) {
      setFormData(settings);
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    onClose();
  };

  return (
    <div id="settings-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              System Configuration
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Circulation &amp; Fines Policy
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-sans">
          {/* Library Name */}
          <div>
            <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Library Institution Name
            </label>
            <input
              type="text"
              value={formData.libraryName}
              onChange={(e) => setFormData({ ...formData, libraryName: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
            />
          </div>

          {/* Late fee settings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Daily Late Fine Rate ($)
              </label>
              <input
                type="number"
                step="0.05"
                min="0"
                value={formData.dailyLateFeeRate}
                onChange={(e) => setFormData({ ...formData, dailyLateFeeRate: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
              <p className="text-[10px] text-[#1A1A1A]/60 mt-1">Charged per day overdue after grace period</p>
            </div>

            <div>
              <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Grace Period (Days)
              </label>
              <input
                type="number"
                min="0"
                value={formData.gracePeriodDays}
                onChange={(e) => setFormData({ ...formData, gracePeriodDays: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
              <p className="text-[10px] text-[#1A1A1A]/60 mt-1">Calendar leniency days prior to fine assessment</p>
            </div>
          </div>

          {/* Loan Duration & Renewals */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Standard Loan Period (Days)
              </label>
              <input
                type="number"
                min="1"
                value={formData.standardLoanDays}
                onChange={(e) => setFormData({ ...formData, standardLoanDays: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Max Renewals Permitted
              </label>
              <input
                type="number"
                min="0"
                value={formData.maxRenewalsAllowed}
                onChange={(e) => setFormData({ ...formData, maxRenewalsAllowed: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>
          </div>

          {/* Email Settings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Automated Reminder Frequency
              </label>
              <input
                type="number"
                min="1"
                value={formData.reminderFrequencyDays}
                onChange={(e) => setFormData({ ...formData, reminderFrequencyDays: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
              <p className="text-[10px] text-[#1A1A1A]/60 mt-1">Cycle interval in days between overdue dispatches</p>
            </div>

            <div>
              <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Circulation Contact Email
              </label>
              <input
                type="email"
                value={formData.contactEmail}
                onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>
          </div>

          {/* Footer */}
          <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Save className="w-3.5 h-3.5" /> Commit Policy
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
