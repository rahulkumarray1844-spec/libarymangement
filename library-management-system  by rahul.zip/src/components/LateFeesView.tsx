import React from 'react';
import {
  DollarSign,
  Receipt,
  CheckCircle2,
  AlertTriangle,
  Printer,
  Sliders,
  ShieldCheck,
  Calendar,
  CreditCard,
  UserCheck
} from 'lucide-react';
import { LateFeePayment, Member, LoanTransaction, SystemSettings } from '../types';
import { formatCurrency, computeLateFee } from '../utils/lateFeeCalculator';

interface LateFeesViewProps {
  payments: LateFeePayment[];
  members: Member[];
  loans: LoanTransaction[];
  settings: SystemSettings;
  onPayFines: (member: Member) => void;
  onOpenSettings: () => void;
}

export const LateFeesView: React.FC<LateFeesViewProps> = ({
  payments,
  members,
  loans,
  settings,
  onPayFines,
  onOpenSettings,
}) => {
  const membersWithFines = members.filter(m => m.unpaidFines > 0);
  const totalOutstanding = membersWithFines.reduce((acc, m) => acc + m.unpaidFines, 0);
  const totalCollected = payments.filter(p => p.method !== 'Waived').reduce((acc, p) => acc + p.amount, 0);
  const totalWaived = payments.filter(p => p.method === 'Waived').reduce((acc, p) => acc + p.amount, 0);

  const handlePrintReceipt = (payment: LateFeePayment) => {
    window.print();
  };

  return (
    <div className="space-y-8">
      {/* Top Editorial Metrics */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-[#1A1A1A] pb-3 mb-6">
          <h2 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
            Financial Ledger &amp; Late Fee Penalties
          </h2>
          <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 sm:mt-0">
            Treasury &amp; Fiscal Compliance
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x divide-[#1A1A1A]/20">
          <div className="pt-2 sm:pt-0 sm:pr-4">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-red-700">
              {formatCurrency(totalOutstanding, settings.currencySymbol)}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-red-700 mt-1 block font-semibold">
              Unpaid Fines ({membersWithFines.length} Patrons)
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-emerald-800">
              {formatCurrency(totalCollected, settings.currencySymbol)}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Remitted to Library Fund
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {formatCurrency(totalWaived, settings.currencySymbol)}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Official Exemptions Waived
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:pl-6">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60">Policy Rules</span>
              <button
                onClick={onOpenSettings}
                className="text-[10px] uppercase font-sans tracking-wider text-[#1A1A1A] hover:underline"
              >
                [Edit]
              </button>
            </div>
            <div className="mt-2 text-xs font-sans text-[#1A1A1A] space-y-1">
              <div>Daily Rate: <strong>${settings.dailyLateFeeRate.toFixed(2)}/day</strong></div>
              <div>Grace Window: <strong>{settings.gracePeriodDays} day</strong></div>
            </div>
          </div>
        </div>
      </div>

      {/* Two-Column Grid: Outstanding Debts vs Payment Receipt Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Outstanding Debts */}
        <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1A1A1A] pb-3">
            <div>
              <h3 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
                Pending Patron Debts
              </h3>
              <p className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-0.5">
                Awaiting Fiscal Settlement
              </p>
            </div>
            <span className="px-2 py-0.5 text-[10px] font-sans font-bold bg-red-800 text-white">
              {membersWithFines.length}
            </span>
          </div>

          {membersWithFines.length === 0 ? (
            <div className="p-8 text-center text-xs font-serif italic text-[#1A1A1A]/60">
              All patron accounts are in good standing. No outstanding penalty balances.
            </div>
          ) : (
            <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
              {membersWithFines.map(member => (
                <div
                  key={member.id}
                  className="p-3.5 border border-[#1A1A1A]/20 bg-[#FDFCF8] flex items-center justify-between text-xs hover:border-[#1A1A1A] transition-colors"
                >
                  <div className="space-y-0.5">
                    <div className="font-serif-display font-bold italic text-base text-[#1A1A1A]">{member.name}</div>
                    <div className="font-mono text-[10px] text-[#1A1A1A]/60">{member.memberCode} · {member.role}</div>
                    <div className="text-[10px] font-sans text-[#1A1A1A]/50">{member.email}</div>
                  </div>
                  <div className="text-right space-y-1.5">
                    <div className="font-serif-display text-lg font-bold italic text-red-700">
                      {formatCurrency(member.unpaidFines, settings.currencySymbol)}
                    </div>
                    <button
                      onClick={() => onPayFines(member)}
                      className="px-2.5 py-1 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] font-sans text-[10px] uppercase font-bold tracking-wider transition-colors"
                    >
                      Settle / Waive
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Historical Payment Receipts */}
        <div className="lg:col-span-2 border border-[#1A1A1A] bg-[#FDFCF8] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1A1A1A] pb-3">
            <div>
              <h3 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
                Receipts &amp; Settlement Ledger
              </h3>
              <p className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-0.5">
                Audit Trail of Collected Fees and Waived Balances
              </p>
            </div>
            <Receipt className="w-4 h-4 text-[#1A1A1A]" />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="text-[10px] font-sans uppercase tracking-widest border-b border-[#1A1A1A] text-[#1A1A1A] bg-[#1A1A1A]/5">
                  <th className="px-4 py-2.5 font-normal">Receipt #</th>
                  <th className="px-4 py-2.5 font-normal">Patron Name</th>
                  <th className="px-4 py-2.5 font-normal">Item / Description</th>
                  <th className="px-3 py-2.5 font-normal">Type</th>
                  <th className="px-4 py-2.5 font-normal">Date</th>
                  <th className="px-4 py-2.5 text-right font-normal">Amount</th>
                  <th className="px-3 py-2.5 text-right font-normal">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A]/15">
                {payments.map(p => (
                  <tr key={p.id} className="hover:bg-[#1A1A1A]/5 transition-colors">
                    <td className="px-4 py-3 font-mono font-semibold text-[#1A1A1A]">
                      {p.receiptNumber}
                    </td>
                    <td className="px-4 py-3 font-sans font-bold text-[#1A1A1A]">
                      {p.memberName}
                    </td>
                    <td className="px-4 py-3 text-[#1A1A1A]/70 max-w-xs truncate italic">
                      {p.bookTitle} {p.notes ? `(${p.notes})` : ''}
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={`px-2 py-0.5 text-[9px] font-sans uppercase font-bold tracking-wider ${
                          p.method === 'Waived'
                            ? 'border border-amber-800 text-amber-900 bg-amber-50'
                            : 'border border-emerald-800 text-emerald-900 bg-emerald-50'
                        }`}
                      >
                        {p.method}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-sans text-[11px] text-[#1A1A1A]/60">
                      {p.paymentDate}
                    </td>
                    <td className="px-4 py-3 text-right font-serif-display font-bold italic text-sm text-[#1A1A1A]">
                      {formatCurrency(p.amount, settings.currencySymbol)}
                    </td>
                    <td className="px-3 py-3 text-right">
                      <button
                        onClick={() => handlePrintReceipt(p)}
                        className="p-1 text-[#1A1A1A]/70 hover:text-[#1A1A1A] border border-[#1A1A1A]/30 hover:border-[#1A1A1A]"
                        title="Print Official Receipt"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
