import React, { useState } from 'react';
import { X, Mail, Send, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';
import { LoanTransaction, SystemSettings } from '../types';
import { computeLateFee, formatCurrency } from '../utils/lateFeeCalculator';

interface EmailReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  loan: LoanTransaction | null;
  settings: SystemSettings;
  onConfirmSend: (loan: LoanTransaction, customSubject: string, customBody: string) => void;
}

export const EmailReminderModal: React.FC<EmailReminderModalProps> = ({
  isOpen,
  onClose,
  loan,
  settings,
  onConfirmSend,
}) => {
  if (!isOpen || !loan) return null;

  const feeData = computeLateFee(loan.dueDate, settings);
  const defaultSubject = `[URGENT] Overdue Library Item Notice: "${loan.bookTitle}"`;
  
  const defaultBody = `Dear ${loan.memberName},

Our automated library records indicate that the following item is now OVERDUE:

  • Title: ${loan.bookTitle}
  • Barcode/ISBN: ${loan.bookIsbn}
  • Scheduled Due Date: ${loan.dueDate}
  • Days Overdue: ${feeData.overdueDays} day(s)
  • Accrued Late Fee: ${formatCurrency(feeData.fee, settings.currencySymbol)} (Rate: ${formatCurrency(settings.dailyLateFeeRate, settings.currencySymbol)}/day after ${settings.gracePeriodDays}-day grace)

Please return this item to the Circulation Desk or 24/7 Exterior Book Drop as soon as possible to prevent further late fees and potential temporary suspension of borrowing privileges.

If you have already returned this book within the past 24 hours, please disregard this notice.

Sincerely,
Circulation & Access Services
${settings.libraryName}
Contact: ${settings.contactEmail}`;

  const [subject, setSubject] = useState(defaultSubject);
  const [body, setBody] = useState(defaultBody);
  const [isSending, setIsSending] = useState(false);

  const handleSend = () => {
    setIsSending(true);
    setTimeout(() => {
      onConfirmSend(loan, subject, body);
      setIsSending(false);
      onClose();
    }, 600);
  };

  return (
    <div id="email-reminder-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Notice Dispatch Transmission
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Automated Overdue Reminder
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1 text-xs font-sans">
          {/* Metadata preview */}
          <div className="p-4 border border-[#1A1A1A] bg-[#1A1A1A]/5 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[#1A1A1A]/60">Recipient Patron:</span>
              <span className="font-bold text-[#1A1A1A]">{loan.memberName} &lt;{loan.memberEmail}&gt;</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#1A1A1A]/60">Book Title:</span>
              <span className="font-serif italic text-[#1A1A1A]">{loan.bookTitle}</span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-[#1A1A1A]/15">
              <span className="text-[#1A1A1A]/60">Overdue Status:</span>
              <span className="font-bold text-red-700">
                {feeData.overdueDays} days past due ({formatCurrency(feeData.fee, settings.currencySymbol)} accrued)
              </span>
            </div>
          </div>

          {/* Subject */}
          <div>
            <label htmlFor="email-subject-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Email Subject Line
            </label>
            <input
              id="email-subject-input"
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-medium focus:outline-hidden"
            />
          </div>

          {/* Email Body */}
          <div>
            <label htmlFor="email-body-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Email Notice Content (Template Preview)
            </label>
            <textarea
              id="email-body-input"
              rows={9}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] font-mono text-[11px] leading-relaxed focus:outline-hidden"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#1A1A1A] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
          >
            Cancel
          </button>
          <button
            id="dispatch-email-reminder-btn"
            onClick={handleSend}
            disabled={isSending}
            className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 disabled:opacity-50 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-2 transition-colors shadow-2xs"
          >
            {isSending ? (
              <>Dispatching Notice...</>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                Dispatch Overdue Notice
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
