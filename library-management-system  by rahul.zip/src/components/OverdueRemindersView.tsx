import React, { useState } from 'react';
import {
  Mail,
  Send,
  CheckCircle2,
  Clock,
  AlertTriangle,
  RotateCw,
  Bell,
  Sliders,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { LoanTransaction, EmailReminder, SystemSettings } from '../types';
import { computeLateFee, formatCurrency } from '../utils/lateFeeCalculator';

interface OverdueRemindersViewProps {
  loans: LoanTransaction[];
  emailLogs: EmailReminder[];
  settings: SystemSettings;
  onSendSingleReminder: (loan: LoanTransaction) => void;
  onSendBatchReminders: (overdueLoans: LoanTransaction[]) => void;
}

export const OverdueRemindersView: React.FC<OverdueRemindersViewProps> = ({
  loans,
  emailLogs,
  settings,
  onSendSingleReminder,
  onSendBatchReminders,
}) => {
  const [isBatchRunning, setIsBatchRunning] = useState(false);
  const [activeLogTab, setActiveLogTab] = useState<'pending' | 'logs'>('pending');

  const overdueLoans = loans.filter(l => l.status === 'Overdue');
  const totalRemindersDispatched = emailLogs.length;

  const handleRunBatch = () => {
    if (overdueLoans.length === 0) return;
    setIsBatchRunning(true);
    setTimeout(() => {
      onSendBatchReminders(overdueLoans);
      setIsBatchRunning(false);
    }, 1000);
  };

  return (
    <div className="space-y-8">
      {/* High-Contrast Editorial Banner: Automated Reminder Daemon */}
      <div className="border border-[#1A1A1A] bg-[#1A1A1A] text-[#FDFCF8] p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] px-2 py-0.5 border border-[#FDFCF8] text-[#FDFCF8] font-bold">
              SYSTEM DAEMON
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-emerald-400">
              ● Active &amp; Scheduled
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black italic font-serif-display text-[#FDFCF8] leading-tight">
            Automated Overdue Reminder Engine
          </h2>
          <p className="text-xs font-sans text-[#FDFCF8]/70 max-w-xl leading-relaxed">
            Background task scans catalog loans where <span className="font-mono text-amber-300">due_date &lt; CURRENT_DATE</span> and generates automated notice transmissions with item metadata, days elapsed, and statutory late fees.
          </p>
        </div>

        <div className="shrink-0 self-end md:self-auto">
          <button
            id="batch-dispatch-reminders-btn"
            onClick={handleRunBatch}
            disabled={isBatchRunning || overdueLoans.length === 0}
            className="px-6 py-3 bg-[#FDFCF8] hover:bg-neutral-200 disabled:opacity-40 disabled:cursor-not-allowed text-[#1A1A1A] border border-[#FDFCF8] text-xs font-sans font-bold uppercase tracking-widest flex items-center gap-2 transition-colors shadow-2xs"
          >
            {isBatchRunning ? (
              <>
                <RotateCw className="w-3.5 h-3.5 animate-spin" /> Dispatching Notices...
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" /> Dispatch All ({overdueLoans.length}) Overdue Notices
              </>
            )}
          </button>
        </div>
      </div>

      {/* Editorial Metric Cards */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-[#1A1A1A] pb-3 mb-6">
          <h2 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
            Notification Dispatch Metrics
          </h2>
          <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 sm:mt-0">
            Automated Email Queue
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x divide-[#1A1A1A]/20">
          <div className="pt-2 sm:pt-0 sm:pr-4">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-red-700">
              {overdueLoans.length.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-red-700 mt-1 block font-semibold">
              Pending Overdue Items
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {totalRemindersDispatched.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Notices Dispatched
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {settings.reminderFrequencyDays}d
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Dispatch Cadence
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:pl-6">
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 block mb-1">
              Sender Address
            </span>
            <span className="font-mono text-xs font-bold text-[#1A1A1A] truncate block">
              {settings.contactEmail}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-emerald-800 mt-1 block font-semibold">
              SMTP Protocol Verified
            </span>
          </div>
        </div>
      </div>

      {/* Tab Controls for Overdue List vs Dispatch Audit Logs */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8]">
        <div className="flex items-center justify-between p-4 border-b border-[#1A1A1A]">
          <div className="flex items-center border border-[#1A1A1A] p-0.5 text-xs font-sans uppercase tracking-wider">
            <button
              onClick={() => setActiveLogTab('pending')}
              className={`px-3 py-1.5 transition-all flex items-center gap-1.5 ${
                activeLogTab === 'pending'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-red-500" />
              Pending Overdue Items ({overdueLoans.length})
            </button>
            <button
              onClick={() => setActiveLogTab('logs')}
              className={`px-3 py-1.5 transition-all flex items-center gap-1.5 ${
                activeLogTab === 'logs'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              <FileText className="w-3 h-3" />
              Automated Dispatch History ({emailLogs.length})
            </button>
          </div>
        </div>

        {/* PENDING OVERDUE TAB */}
        {activeLogTab === 'pending' && (
          <div>
            {overdueLoans.length === 0 ? (
              <div className="p-12 text-center text-xs font-serif italic text-[#1A1A1A]/60">
                No overdue loans detected in circulation. Stacks are in order.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="text-[10px] font-sans uppercase tracking-widest border-b border-[#1A1A1A] text-[#1A1A1A] bg-[#1A1A1A]/5">
                      <th className="px-6 py-3 font-normal">Catalog Title</th>
                      <th className="px-5 py-3 font-normal">Patron Borrower</th>
                      <th className="px-4 py-3 font-normal">Due Date</th>
                      <th className="px-4 py-3 font-normal">Overdue Lapse</th>
                      <th className="px-4 py-3 font-normal">Accrued Fine</th>
                      <th className="px-4 py-3 font-normal">Notice Status</th>
                      <th className="px-6 py-3 text-right font-normal">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1A1A1A]/15">
                    {overdueLoans.map(loan => {
                      const feeData = computeLateFee(loan.dueDate, settings);
                      return (
                        <tr key={loan.id} className="hover:bg-[#1A1A1A]/5 transition-colors">
                          <td className="px-6 py-4 max-w-xs">
                            <div className="font-serif-display font-bold italic text-base text-[#1A1A1A]">{loan.bookTitle}</div>
                            <div className="text-[10px] font-mono text-[#1A1A1A]/50">ISBN: {loan.bookIsbn}</div>
                          </td>
                          <td className="px-5 py-4">
                            <div className="font-sans font-bold text-sm text-[#1A1A1A]">{loan.memberName}</div>
                            <div className="text-[11px] font-sans text-[#1A1A1A]/60">{loan.memberEmail}</div>
                          </td>
                          <td className="px-4 py-4 font-sans text-xs text-[#1A1A1A]">
                            {loan.dueDate}
                          </td>
                          <td className="px-4 py-4 font-sans font-bold text-red-700">
                            {feeData.overdueDays} days overdue
                          </td>
                          <td className="px-4 py-4 font-serif-display font-bold italic text-base text-red-700">
                            {formatCurrency(feeData.fee, settings.currencySymbol)}
                          </td>
                          <td className="px-4 py-4 text-[#1A1A1A]/60 text-xs">
                            {loan.lastReminderSentDate ? (
                              <span>{loan.lastReminderSentDate} ({loan.remindersSentCount} sent)</span>
                            ) : (
                              <span className="text-[#1A1A1A]/40 italic">None yet</span>
                            )}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button
                              onClick={() => onSendSingleReminder(loan)}
                              className="px-3 py-1.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] text-[10px] font-sans uppercase font-bold tracking-widest inline-flex items-center gap-1.5 ml-auto transition-colors"
                            >
                              <Mail className="w-3 h-3" /> Send Notice
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* AUDIT LOGS TAB */}
        {activeLogTab === 'logs' && (
          <div>
            {emailLogs.length === 0 ? (
              <div className="p-12 text-center text-xs font-serif italic text-[#1A1A1A]/60">
                No email dispatch logs recorded yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="text-[10px] font-sans uppercase tracking-widest border-b border-[#1A1A1A] text-[#1A1A1A] bg-[#1A1A1A]/5">
                      <th className="px-6 py-3 font-normal">Timestamp</th>
                      <th className="px-5 py-3 font-normal">Recipient Patron</th>
                      <th className="px-5 py-3 font-normal">Subject</th>
                      <th className="px-5 py-3 font-normal">Item Overdue</th>
                      <th className="px-4 py-3 font-normal">Fine Quoted</th>
                      <th className="px-6 py-3 text-right font-normal">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1A1A1A]/15">
                    {emailLogs.map(log => (
                      <tr key={log.id} className="hover:bg-[#1A1A1A]/5 transition-colors">
                        <td className="px-6 py-4 font-sans text-xs text-[#1A1A1A]/70 whitespace-nowrap">
                          {new Date(log.sentAt).toLocaleString()}
                        </td>
                        <td className="px-5 py-4">
                          <div className="font-sans font-bold text-sm text-[#1A1A1A]">{log.memberName}</div>
                          <div className="text-[11px] font-sans text-[#1A1A1A]/50">{log.memberEmail}</div>
                        </td>
                        <td className="px-5 py-4 font-sans text-xs text-[#1A1A1A] max-w-xs truncate">
                          {log.subject}
                        </td>
                        <td className="px-5 py-4 font-serif-display italic text-sm text-[#1A1A1A] max-w-[180px] truncate">
                          {log.bookTitle}
                        </td>
                        <td className="px-4 py-4 font-serif-display font-bold italic text-base text-red-700">
                          {formatCurrency(log.fineAmount, settings.currencySymbol)}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className="text-[9px] font-sans uppercase font-bold tracking-widest px-2 py-0.5 border border-emerald-800 text-emerald-900 bg-emerald-50">
                            {log.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
