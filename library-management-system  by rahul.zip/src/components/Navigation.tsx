import React from 'react';
import {
  Library,
  BookOpen,
  ArrowLeftRight,
  Users,
  DollarSign,
  Mail,
  Database,
  Camera,
  BookPlus,
  ArrowDownLeft,
  Search,
  RotateCcw,
  Sliders
} from 'lucide-react';
import { SystemSettings } from '../types';

export type ActiveTab =
  | 'inventory'
  | 'circulation'
  | 'members'
  | 'late_fees'
  | 'reminders'
  | 'database';

interface NavigationProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  settings: SystemSettings;
  overdueCount: number;
  unpaidFinesTotal: number;
  onOpenScanner: () => void;
  onOpenIssueModal: () => void;
  onOpenReturnModal: () => void;
  onResetData: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenSettings: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  setActiveTab,
  settings,
  overdueCount,
  unpaidFinesTotal,
  onOpenScanner,
  onOpenIssueModal,
  onOpenReturnModal,
  onResetData,
  searchQuery,
  setSearchQuery,
  onOpenSettings,
}) => {
  const currentDateFormatted = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: '2-digit',
    year: 'numeric',
  }).format(new Date());

  return (
    <header className="bg-[#FDFCF8] border-b border-[#1A1A1A] sticky top-0 z-40">
      {/* Top Editorial Masthead & Utility Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-4 border-b border-[#1A1A1A]">
          {/* Masthead Logo & Name */}
          <div className="flex items-baseline gap-4">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tighter uppercase italic font-serif-display text-[#1A1A1A] leading-none">
                  Archive
                </h1>
                <span className="text-[10px] font-sans font-bold uppercase tracking-[0.2em] px-2 py-0.5 border border-[#1A1A1A] bg-[#1A1A1A] text-[#FDFCF8]">
                  v4.0.2
                </span>
              </div>
              <p className="text-[10px] sm:text-xs font-sans tracking-widest uppercase mt-1.5 text-[#1A1A1A]/70">
                {settings.libraryName} — Central Circulation &amp; Archive System
              </p>
            </div>
          </div>

          {/* Editorial Meta Status: System Status, Date & Quick Tools */}
          <div className="flex flex-wrap items-center gap-6 sm:gap-10 text-right">
            <div>
              <p className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/50">System Status</p>
              <p className="text-xs sm:text-sm font-sans font-bold uppercase text-emerald-800 flex items-center gap-1.5 justify-end">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
                Live / Barcode Ready
              </p>
            </div>

            <div>
              <p className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/50">Date</p>
              <p className="text-xs sm:text-sm font-sans font-bold uppercase text-[#1A1A1A]">
                {currentDateFormatted}
              </p>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex items-center space-x-2">
              <button
                id="header-barcode-scan-btn"
                onClick={onOpenScanner}
                className="px-3.5 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-[11px] font-sans font-bold uppercase tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs"
                title="Open Barcode & RFID Scanner"
              >
                <Camera className="w-3.5 h-3.5 text-[#FDFCF8]" />
                <span className="hidden sm:inline">Scan Barcode</span>
              </button>

              <button
                id="header-issue-book-btn"
                onClick={onOpenIssueModal}
                className="px-3.5 py-2 bg-transparent hover:bg-[#1A1A1A] hover:text-[#FDFCF8] text-[#1A1A1A] border border-[#1A1A1A] text-[11px] font-sans font-bold uppercase tracking-widest flex items-center gap-1.5 transition-colors"
                title="Issue Book (Checkout)"
              >
                <BookPlus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Issue</span>
              </button>

              <button
                id="header-return-book-btn"
                onClick={onOpenReturnModal}
                className="px-3.5 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-[11px] font-sans font-bold uppercase tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs"
                title="Return Book (Check-in)"
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Return</span>
              </button>

              <div className="h-6 w-px bg-[#1A1A1A]/20 mx-1 hidden sm:block"></div>

              <button
                id="header-settings-btn"
                onClick={onOpenSettings}
                className="p-2 text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
                title="System & Fee Policies"
              >
                <Sliders className="w-4 h-4" />
              </button>

              <button
                id="header-reset-sample-btn"
                onClick={onResetData}
                className="p-2 text-[#1A1A1A]/60 hover:text-red-700 hover:bg-red-50 border border-transparent hover:border-red-300 transition-colors"
                title="Reset to Default Course Sample Data"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Search & Navigation Tab Strip */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pt-3">
          {/* Tab Navigation Menu */}
          <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto no-scrollbar">
            <button
              id="nav-tab-inventory"
              onClick={() => setActiveTab('inventory')}
              className={`py-2 px-3 text-xs uppercase tracking-[0.15em] font-sans whitespace-nowrap flex items-center gap-2 transition-all ${
                activeTab === 'inventory'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold shadow-2xs'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              Inventory
            </button>

            <button
              id="nav-tab-circulation"
              onClick={() => setActiveTab('circulation')}
              className={`py-2 px-3 text-xs uppercase tracking-[0.15em] font-sans whitespace-nowrap flex items-center gap-2 transition-all relative ${
                activeTab === 'circulation'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold shadow-2xs'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              Circulation
              {overdueCount > 0 && (
                <span className="px-1.5 py-0.2 text-[9px] font-sans font-bold bg-red-700 text-white">
                  {overdueCount}
                </span>
              )}
            </button>

            <button
              id="nav-tab-members"
              onClick={() => setActiveTab('members')}
              className={`py-2 px-3 text-xs uppercase tracking-[0.15em] font-sans whitespace-nowrap flex items-center gap-2 transition-all ${
                activeTab === 'members'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold shadow-2xs'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Patrons
            </button>

            <button
              id="nav-tab-late-fees"
              onClick={() => setActiveTab('late_fees')}
              className={`py-2 px-3 text-xs uppercase tracking-[0.15em] font-sans whitespace-nowrap flex items-center gap-2 transition-all ${
                activeTab === 'late_fees'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold shadow-2xs'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              Late Fees
              {unpaidFinesTotal > 0 && (
                <span className="text-[9px] font-bold bg-amber-200 text-amber-950 px-1 py-0.2">
                  ${unpaidFinesTotal.toFixed(2)}
                </span>
              )}
            </button>

            <button
              id="nav-tab-reminders"
              onClick={() => setActiveTab('reminders')}
              className={`py-2 px-3 text-xs uppercase tracking-[0.15em] font-sans whitespace-nowrap flex items-center gap-2 transition-all ${
                activeTab === 'reminders'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold shadow-2xs'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              Reminders
              {overdueCount > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></span>
              )}
            </button>

            <button
              id="nav-tab-database"
              onClick={() => setActiveTab('database')}
              className={`py-2 px-3 text-xs uppercase tracking-[0.15em] font-sans whitespace-nowrap flex items-center gap-2 transition-all ${
                activeTab === 'database'
                  ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold shadow-2xs'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              SQL &amp; JDBC
            </button>
          </nav>

          {/* Quick Search in Editorial Style */}
          <div className="w-full md:w-72 shrink-0">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#1A1A1A]/40 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="global-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search Archive..."
                className="w-full pl-8 pr-4 py-1.5 bg-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 transition-colors focus:outline-hidden focus:ring-1 focus:ring-[#1A1A1A]"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#1A1A1A]/50 hover:text-[#1A1A1A] text-[10px] uppercase font-sans tracking-wider"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
