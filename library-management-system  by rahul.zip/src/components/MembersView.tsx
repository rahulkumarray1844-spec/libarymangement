import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Edit,
  CreditCard,
  DollarSign,
  BookOpen,
  ShieldAlert,
  ShieldCheck,
  CheckCircle,
  GraduationCap,
  Building,
  ArrowRight,
  Printer
} from 'lucide-react';
import { Member, SystemSettings } from '../types';
import { formatCurrency } from '../utils/lateFeeCalculator';

interface MembersViewProps {
  members: Member[];
  settings: SystemSettings;
  searchQuery: string;
  onAddNewMember: () => void;
  onEditMember: (member: Member) => void;
  onOpenCardModal: (member: Member) => void;
  onPayFines: (member: Member) => void;
  onIssueToMember: (member: Member) => void;
}

export const MembersView: React.FC<MembersViewProps> = ({
  members,
  settings,
  searchQuery,
  onAddNewMember,
  onEditMember,
  onOpenCardModal,
  onPayFines,
  onIssueToMember,
}) => {
  const [roleFilter, setRoleFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  const roles = ['All', 'Student', 'Faculty', 'Researcher', 'Community'];

  const filteredMembers = members.filter(m => {
    const matchesSearch =
      !searchQuery ||
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.memberCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (m.departmentOrProgram && m.departmentOrProgram.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesRole = roleFilter === 'All' || m.role === roleFilter;
    const matchesStatus = statusFilter === 'All' || m.status === statusFilter;

    return matchesSearch && matchesRole && matchesStatus;
  });

  const totalMembers = members.length;
  const studentCount = members.filter(m => m.role === 'Student').length;
  const facultyCount = members.filter(m => m.role === 'Faculty' || m.role === 'Researcher').length;
  const patronsWithFines = members.filter(m => m.unpaidFines > 0).length;

  return (
    <div className="space-y-8">
      {/* Top Editorial Metric Cards */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between border-b border-[#1A1A1A] pb-3 mb-6">
          <h2 className="text-xs font-sans uppercase tracking-[0.2em] font-bold text-[#1A1A1A]">
            Patron Roster &amp; User Registry
          </h2>
          <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 sm:mt-0">
            Certified Library Cardholders
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x divide-[#1A1A1A]/20">
          <div className="pt-2 sm:pt-0 sm:pr-4">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {totalMembers.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Registered Cardholders
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {studentCount.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Student Scholars
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:px-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-[#1A1A1A]">
              {facultyCount.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/60 mt-1 block">
              Faculty &amp; Research Fellows
            </span>
          </div>

          <div className="pt-4 sm:pt-0 sm:pl-6">
            <span className="text-3xl sm:text-4xl lg:text-5xl block font-black italic font-serif-display text-red-700">
              {patronsWithFines.toLocaleString()}
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest text-red-700 mt-1 block font-semibold">
              Patrons with Pending Debt
            </span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="border border-[#1A1A1A] bg-[#FDFCF8] p-4 flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
        <div className="flex flex-wrap items-center gap-2">
          {/* Role Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {roles.map(r => (
              <button
                key={r}
                onClick={() => setRoleFilter(r)}
                className={`px-3 py-1.5 text-xs font-sans uppercase tracking-wider transition-colors whitespace-nowrap border ${
                  roleFilter === r
                    ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A] font-bold'
                    : 'bg-transparent text-[#1A1A1A]/70 border-[#1A1A1A]/30 hover:border-[#1A1A1A]'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="h-5 w-px bg-[#1A1A1A]/20 hidden sm:block"></div>

          {/* Status Filter */}
          <div className="flex items-center border border-[#1A1A1A] p-0.5 text-xs font-sans uppercase tracking-wider">
            <button
              onClick={() => setStatusFilter('All')}
              className={`px-2.5 py-1 transition-all ${
                statusFilter === 'All' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              All Status
            </button>
            <button
              onClick={() => setStatusFilter('Active')}
              className={`px-2.5 py-1 transition-all ${
                statusFilter === 'Active' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              Active
            </button>
            <button
              onClick={() => setStatusFilter('Suspended')}
              className={`px-2.5 py-1 transition-all ${
                statusFilter === 'Suspended' ? 'bg-[#1A1A1A] text-[#FDFCF8] font-bold' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
              }`}
            >
              Suspended
            </button>
          </div>
        </div>

        <button
          id="add-new-member-btn"
          onClick={onAddNewMember}
          className="px-4 py-2 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-1.5 transition-colors shadow-2xs self-end sm:self-auto shrink-0"
        >
          <UserPlus className="w-3.5 h-3.5" /> Register Patron
        </button>
      </div>

      {/* Member Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map((member) => {
          const isAtLimit = member.currentBorrowedCount >= member.maxBorrowLimit;
          const hasFines = member.unpaidFines > 0;

          return (
            <div
              key={member.id}
              className="border border-[#1A1A1A] bg-[#FDFCF8] flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              <div className="p-6 border-b border-[#1A1A1A] space-y-4">
                <div className="flex items-start justify-between border-b border-[#1A1A1A]/15 pb-2">
                  <div>
                    <h3 className="font-serif-display text-2xl font-bold italic text-[#1A1A1A] leading-tight">
                      {member.name}
                    </h3>
                    <p className="text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/60 mt-0.5">
                      {member.departmentOrProgram || member.role}
                    </p>
                  </div>
                  <span
                    className={`text-[9px] font-sans font-bold uppercase tracking-widest px-2 py-0.5 ${
                      member.status === 'Active'
                        ? 'border border-emerald-800 text-emerald-900 bg-emerald-50'
                        : 'border border-red-700 text-red-800 bg-red-100'
                    }`}
                  >
                    {member.status}
                  </span>
                </div>

                <div className="border border-[#1A1A1A]/15 p-3 space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="font-sans uppercase text-[10px] text-[#1A1A1A]/60">Barcode ID:</span>
                    <span className="font-mono font-bold text-[#1A1A1A]">{member.memberCode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-sans uppercase text-[10px] text-[#1A1A1A]/60">Category:</span>
                    <span className="font-sans text-[#1A1A1A] font-semibold">{member.role}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-sans uppercase text-[10px] text-[#1A1A1A]/60">Email:</span>
                    <span className="font-sans text-[#1A1A1A] truncate max-w-[180px]">{member.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-sans uppercase text-[10px] text-[#1A1A1A]/60">Phone:</span>
                    <span className="font-sans text-[#1A1A1A]">{member.phone}</span>
                  </div>
                </div>

                {/* Borrowing Limit Meter */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-sans uppercase text-[10px] tracking-wider text-[#1A1A1A]/60">Borrowing Quota:</span>
                    <span className={`font-sans font-bold text-xs ${isAtLimit ? 'text-red-700' : 'text-[#1A1A1A]'}`}>
                      {member.currentBorrowedCount} of {member.maxBorrowLimit} books
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-[#1A1A1A]/10 border border-[#1A1A1A]/20">
                    <div
                      className={`h-full transition-all ${
                        isAtLimit ? 'bg-red-700' : 'bg-[#1A1A1A]'
                      }`}
                      style={{ width: `${Math.min(100, (member.currentBorrowedCount / member.maxBorrowLimit) * 100)}%` }}
                    ></div>
                  </div>
                </div>

                {/* Fine Warning if any */}
                {hasFines && (
                  <div className="p-3 border border-red-700 bg-red-50/50 flex items-center justify-between text-xs">
                    <span className="font-sans uppercase tracking-wider text-red-900 font-bold text-[10px]">Outstanding Late Fines:</span>
                    <span className="font-serif-display text-base font-bold italic text-red-700">
                      {formatCurrency(member.unpaidFines, settings.currencySymbol)}
                    </span>
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="p-4 px-6 bg-[#FDFCF8] flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onOpenCardModal(member)}
                    className="p-1.5 text-[#1A1A1A] border border-[#1A1A1A]/30 hover:border-[#1A1A1A] transition-colors"
                    title="View Digital Library Pass & Barcode"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onEditMember(member)}
                    className="p-1.5 text-[#1A1A1A] border border-[#1A1A1A]/30 hover:border-[#1A1A1A] transition-colors"
                    title="Edit Patron Details"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                  {hasFines && (
                    <button
                      onClick={() => onPayFines(member)}
                      className="px-2.5 py-1 bg-red-800 hover:bg-red-900 text-white text-[10px] font-sans font-bold uppercase tracking-wider transition-colors"
                      title="Settle Outstanding Fines"
                    >
                      Settle Debt
                    </button>
                  )}
                </div>

                {member.status === 'Active' && !isAtLimit && (
                  <button
                    onClick={() => onIssueToMember(member)}
                    className="px-3.5 py-1.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] text-[11px] font-sans font-bold uppercase tracking-widest flex items-center gap-1 transition-colors"
                  >
                    Issue Book <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
