import React, { useState, useEffect } from 'react';
import { X, BookPlus, Edit3, Bookmark, MapPin, Hash, Barcode } from 'lucide-react';
import { Book } from '../types';

interface BookFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveBook: (bookData: Omit<Book, 'id'>, existingId?: string) => void;
  editingBook?: Book | null;
}

const CATEGORIES = [
  'Computer Science',
  'Software Engineering',
  'Mathematics & Computing',
  'Database Systems',
  'Classic Literature',
  'Dystopian Fiction',
  'History & Anthropology',
  'Physics & Chemistry',
  'Philosophy & Ethics',
  'Business & Economics',
];

export const BookFormModal: React.FC<BookFormModalProps> = ({
  isOpen,
  onClose,
  onSaveBook,
  editingBook,
}) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [publishYear, setPublishYear] = useState<number>(2024);
  const [shelfLocation, setShelfLocation] = useState('');
  const [totalCopies, setTotalCopies] = useState<number>(3);
  const [description, setDescription] = useState('');
  const [publisher, setPublisher] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (editingBook) {
        setTitle(editingBook.title);
        setAuthor(editingBook.author);
        setIsbn(editingBook.isbn);
        setCategory(editingBook.category);
        setPublishYear(editingBook.publishYear);
        setShelfLocation(editingBook.shelfLocation);
        setTotalCopies(editingBook.totalCopies);
        setDescription(editingBook.description || '');
        setPublisher(editingBook.publisher || '');
      } else {
        // Random new ISBN
        const randomIsbn = '978' + Math.floor(1000000000 + Math.random() * 9000000000).toString();
        setTitle('');
        setAuthor('');
        setIsbn(randomIsbn);
        setCategory(CATEGORIES[0]);
        setPublishYear(new Date().getFullYear());
        setShelfLocation('Stack 4 - CS-15');
        setTotalCopies(3);
        setDescription('');
        setPublisher('');
      }
    }
  }, [isOpen, editingBook]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !author.trim() || !isbn.trim()) return;

    const availableCopies = editingBook
      ? Math.max(0, editingBook.availableCopies + (totalCopies - editingBook.totalCopies))
      : totalCopies;

    onSaveBook(
      {
        title: title.trim(),
        author: author.trim(),
        isbn: isbn.trim(),
        category,
        publishYear: Number(publishYear),
        shelfLocation: shelfLocation.trim() || 'General Stacks',
        totalCopies: Number(totalCopies),
        availableCopies: Number(availableCopies),
        description: description.trim(),
        publisher: publisher.trim(),
        addedDate: editingBook ? editingBook.addedDate : new Date().toISOString().split('T')[0],
      },
      editingBook?.id
    );

    onClose();
  };

  return (
    <div id="book-form-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Accession Catalog Record
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              {editingBook ? 'Edit Book Record' : 'Catalog New Book'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto flex-1">
          {/* Title */}
          <div>
            <label htmlFor="book-title-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Book Title *
            </label>
            <input
              id="book-title-input"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Structure and Interpretation of Computer Programs"
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Author */}
          <div>
            <label htmlFor="book-author-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Author(s) *
            </label>
            <input
              id="book-author-input"
              type="text"
              required
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="e.g. Harold Abelson, Gerald Jay Sussman"
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* ISBN & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="book-isbn-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                ISBN / Barcode ID *
              </label>
              <div className="relative">
                <input
                  id="book-isbn-input"
                  type="text"
                  required
                  value={isbn}
                  onChange={(e) => setIsbn(e.target.value)}
                  placeholder="9780262510875"
                  className="w-full pl-8 pr-3 py-2 bg-transparent border border-[#1A1A1A] text-xs font-mono focus:outline-hidden"
                />
                <Barcode className="w-3.5 h-3.5 text-[#1A1A1A]/60 absolute left-2.5 top-2.5" />
              </div>
            </div>

            <div>
              <label htmlFor="book-category-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Category
              </label>
              <select
                id="book-category-input"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Shelf Location, Copies, Year */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="book-shelf-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Shelf Location
              </label>
              <input
                id="book-shelf-input"
                type="text"
                value={shelfLocation}
                onChange={(e) => setShelfLocation(e.target.value)}
                placeholder="Stack 4 - CS-15"
                className="w-full px-3 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
              />
            </div>

            <div>
              <label htmlFor="book-year-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Publication Year
              </label>
              <input
                id="book-year-input"
                type="number"
                value={publishYear}
                onChange={(e) => setPublishYear(Number(e.target.value))}
                className="w-full px-3 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>

            <div>
              <label htmlFor="book-copies-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
                Total Copies
              </label>
              <input
                id="book-copies-input"
                type="number"
                min={1}
                value={totalCopies}
                onChange={(e) => setTotalCopies(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
              />
            </div>
          </div>

          {/* Publisher */}
          <div>
            <label htmlFor="book-publisher-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Publisher (Optional)
            </label>
            <input
              id="book-publisher-input"
              type="text"
              value={publisher}
              onChange={(e) => setPublisher(e.target.value)}
              placeholder="e.g. MIT Press, McGraw-Hill"
              className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Description */}
          <div>
            <label htmlFor="book-desc-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1">
              Synopsis / Subject Notes
            </label>
            <textarea
              id="book-desc-input"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief summary or scope of this edition..."
              className="w-full px-3.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40 focus:outline-hidden"
            />
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
            >
              Cancel
            </button>
            <button
              id="save-book-btn"
              type="submit"
              className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest transition-colors shadow-2xs"
            >
              {editingBook ? 'Update Book Record' : 'Commit to Catalog'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
