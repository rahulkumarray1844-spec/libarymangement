import React, { useState, useEffect } from 'react';
import { X, CheckCircle, AlertTriangle, DollarSign, Receipt, ArrowDownLeft } from 'lucide-react';
import confetti from 'canvas-confetti';
import { LoanTransaction, SystemSettings, LateFeePayment } from '../types';
import { computeLateFee, formatCurrency } from '../utils/lateFeeCalculator';

interface ReturnBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  loans: LoanTransaction[];
  settings: SystemSettings;
  preselectedLoan?: LoanTransaction | null;
  onConfirmReturn: (
    loanId: string,
    returnDate: string,
    fineAmount: number,
    paymentOption: 'pay_now' | 'defer' | 'waive',
    paymentMethod: 'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived',
    waiverReason?: string
  ) => void;
}

export const ReturnBookModal: React.FC<ReturnBookModalProps> = ({
  isOpen,
  onClose,
  loans,
  settings,
  preselectedLoan,
  onConfirmReturn,
}) => {
  const activeLoans = loans.filter(l => l.status === 'Active' || l.status === 'Overdue');
  const [selectedLoanId, setSelectedLoanId] = useState<string>('');
  const [returnDate, setReturnDate] = useState<string>('');
  const [paymentOption, setPaymentOption] = useState<'pay_now' | 'defer' | 'waive'>('pay_now');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Credit Card' | 'Campus Pay' | 'Waived'>('Cash');
  const [waiverReason, setWaiverReason] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      const todayStr = new Date().toISOString().split('T')[0];
      setReturnDate(todayStr);
      setSelectedLoanId(preselectedLoan?.id || (activeLoans[0]?.id || ''));
      setPaymentOption('pay_now');
      setPaymentMethod('Cash');
      setWaiverReason('');
    }
  }, [isOpen, preselectedLoan]);

  if (!isOpen) return null;

  const currentLoan = loans.find(l => l.id === selectedLoanId);
  const feeCalc = currentLoan ? computeLateFee(currentLoan.dueDate, settings, returnDate) : { overdueDays: 0, chargeableDays: 0, fee: 0 };
  const hasLateFee = feeCalc.fee > 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentLoan) return;

    if (!hasLateFee) {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch (err) {}
    }

    onConfirmReturn(
      currentLoan.id,
      returnDate,
      feeCalc.fee,
      hasLateFee ? paymentOption : 'pay_now',
      paymentOption === 'waive' ? 'Waived' : paymentMethod,
      waiverReason.trim() || undefined
    );

    onClose();
  };

  return (
    <div id="return-book-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Circulation Check-in
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Return Book (Check-in)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Select Loan */}
          <div>
            <label htmlFor="select-return-loan" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
              Active Loan Record *
            </label>
            <select
              id="select-return-loan"
              value={selectedLoanId}
              onChange={(e) => setSelectedLoanId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
            >
              {activeLoans.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.bookTitle} — Borrowed by {l.memberName} (Due: {l.dueDate})
                </option>
              ))}
            </select>
          </div>

          {currentLoan && (
            <div className="p-4 border border-[#1A1A1A] text-xs font-sans space-y-1.5 bg-[#1A1A1A]/5">
              <div className="flex justify-between">
                <span className="text-[#1A1A1A]/60">Catalog Title:</span>
                <span className="font-serif italic font-bold text-[#1A1A1A]">{currentLoan.bookTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#1A1A1A]/60">Borrowing Patron:</span>
                <span className="font-bold text-[#1A1A1A]">{currentLoan.memberName} ({currentLoan.memberCode})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#1A1A1A]/60">Issue Date:</span>
                <span className="font-mono text-[#1A1A1A]">{currentLoan.issueDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#1A1A1A]/60">Scheduled Due Date:</span>
                <span className="font-mono font-bold text-[#1A1A1A]">{currentLoan.dueDate}</span>
              </div>
            </div>
          )}

          {/* Return Date */}
          <div>
            <label htmlFor="return-date-input" className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A] mb-1.5">
              Recorded Return Date
            </label>
            <input
              id="return-date-input"
              type="date"
              value={returnDate}
              onChange={(e) => setReturnDate(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 bg-transparent border border-[#1A1A1A] text-xs font-sans focus:outline-hidden"
            />
          </div>

          {/* Late Fee Calculation Section */}
          {hasLateFee ? (
            <div className="p-4 border border-red-700 bg-red-50/50 space-y-3">
              <div className="flex items-center gap-2 text-red-900 font-bold text-xs uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4 text-red-700 shrink-0" />
                <span>Overdue Item Detected</span>
              </div>

              {/* Breakdown */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-[#FDFCF8] border border-[#1A1A1A]">
                  <div className="text-[9px] uppercase tracking-widest text-[#1A1A1A]/60">Overdue</div>
                  <div className="text-base font-black italic font-serif-display text-red-700">{feeCalc.overdueDays}d</div>
                </div>
                <div className="p-2 bg-[#FDFCF8] border border-[#1A1A1A]">
                  <div className="text-[9px] uppercase tracking-widest text-[#1A1A1A]/60">Grace Period</div>
                  <div className="text-base font-black italic font-serif-display text-[#1A1A1A]">{settings.gracePeriodDays}d</div>
                </div>
                <div className="p-2 bg-[#FDFCF8] border border-[#1A1A1A]">
                  <div className="text-[9px] uppercase tracking-widest text-[#1A1A1A]/60">Rate / Day</div>
                  <div className="text-base font-black italic font-serif-display text-[#1A1A1A]">${settings.dailyLateFeeRate.toFixed(2)}</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-red-700/30">
                <span className="text-[10px] font-sans uppercase tracking-widest font-bold text-red-900">Calculated Late Fine:</span>
                <span className="text-2xl font-black italic font-serif-display text-red-700">
                  {formatCurrency(feeCalc.fee, settings.currencySymbol)}
                </span>
              </div>

              {/* Payment Settlement Options */}
              <div className="pt-2 border-t border-red-700/30 space-y-2">
                <label className="block text-[10px] font-sans font-bold uppercase tracking-widest text-[#1A1A1A]">Fine Settlement Method</label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentOption('pay_now')}
                    className={`py-2 px-2 text-[10px] font-sans uppercase font-bold tracking-wider border transition-all ${
                      paymentOption === 'pay_now'
                        ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A]'
                        : 'bg-[#FDFCF8] text-[#1A1A1A] border-[#1A1A1A]/40'
                    }`}
                  >
                    Pay Now
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentOption('defer')}
                    className={`py-2 px-2 text-[10px] font-sans uppercase font-bold tracking-wider border transition-all ${
                      paymentOption === 'defer'
                        ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A]'
                        : 'bg-[#FDFCF8] text-[#1A1A1A] border-[#1A1A1A]/40'
                    }`}
                  >
                    Post to Account
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentOption('waive')}
                    className={`py-2 px-2 text-[10px] font-sans uppercase font-bold tracking-wider border transition-all ${
                      paymentOption === 'waive'
                        ? 'bg-[#1A1A1A] text-[#FDFCF8] border-[#1A1A1A]'
                        : 'bg-[#FDFCF8] text-[#1A1A1A] border-[#1A1A1A]/40'
                    }`}
                  >
                    Waive Fine
                  </button>
                </div>

                {paymentOption === 'pay_now' && (
                  <div className="pt-1">
                    <label className="block text-[10px] font-sans uppercase tracking-wider text-[#1A1A1A]/70 mb-1">Receipt Tender Mode</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="w-full px-2.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans"
                    >
                      <option value="Cash">Cash (Circulation Counter)</option>
                      <option value="Credit Card">Credit / Debit Card</option>
                      <option value="Campus Pay">Campus Pay / Student Card</option>
                    </select>
                  </div>
                )}

                {paymentOption === 'waive' && (
                  <div className="pt-1">
                    <label className="block text-[10px] font-sans uppercase tracking-wider text-[#1A1A1A]/70 mb-1">Reason for Administrative Waiver</label>
                    <input
                      type="text"
                      value={waiverReason}
                      onChange={(e) => setWaiverReason(e.target.value)}
                      placeholder="e.g. Medical emergency, First-time leniency"
                      className="w-full px-2.5 py-2 bg-transparent border border-[#1A1A1A] text-xs font-sans placeholder-[#1A1A1A]/40"
                    />
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-3 border border-emerald-800 bg-emerald-50 flex items-center gap-2 text-xs text-emerald-900 font-sans">
              <CheckCircle className="w-4 h-4 text-emerald-800 shrink-0" />
              <span>Returned on schedule. Zero late fines assessed.</span>
            </div>
          )}

          {/* Actions */}
          <div className="pt-4 border-t border-[#1A1A1A] flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
            >
              Cancel
            </button>
            <button
              id="confirm-return-book-btn"
              type="submit"
              disabled={!currentLoan}
              className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest transition-colors shadow-2xs"
            >
              Complete Check-in
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
