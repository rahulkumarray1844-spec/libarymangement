import React, { useRef } from 'react';
import { X, Printer, Download, BookOpen, Tag } from 'lucide-react';
import { Book } from '../types';
import { BarcodeRenderer } from './BarcodeRenderer';

interface BarcodeLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  book: Book | null;
}

export const BarcodeLabelModal: React.FC<BarcodeLabelModalProps> = ({
  isOpen,
  onClose,
  book,
}) => {
  const printRef = useRef<HTMLDivElement | null>(null);

  if (!isOpen || !book) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="barcode-label-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 animate-in fade-in">
      <div className="bg-[#FDFCF8] border border-[#1A1A1A] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#1A1A1A] bg-[#FDFCF8]">
          <div>
            <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#1A1A1A]/60 block mb-0.5">
              Ex-Libris Bookplate
            </span>
            <h2 className="text-2xl font-black italic font-serif-display text-[#1A1A1A]">
              Spine &amp; Catalog Barcode
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#1A1A1A]/60 hover:text-[#1A1A1A] hover:bg-[#1A1A1A]/10 border border-transparent hover:border-[#1A1A1A]/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Label View */}
        <div className="p-8 flex flex-col items-center justify-center bg-[#1A1A1A]/5">
          <div
            ref={printRef}
            id="printable-barcode-card"
            className="w-full max-w-sm bg-[#FDFCF8] p-6 border-2 border-[#1A1A1A] flex flex-col items-center text-center space-y-3 shadow-2xs"
          >
            <div className="text-[10px] font-sans font-bold uppercase tracking-[0.25em] text-[#1A1A1A] border-b border-[#1A1A1A] pb-1 w-full text-center">
              Central University Library
            </div>

            <div className="space-y-1">
              <h3 className="font-serif-display font-bold italic text-lg text-[#1A1A1A] leading-tight">
                {book.title}
              </h3>
              <p className="text-xs font-sans text-[#1A1A1A]/70">{book.author} ({book.publishYear})</p>
            </div>

            {/* Generated Barcode */}
            <div className="py-2">
              <BarcodeRenderer
                value={book.isbn}
                width={1.7}
                height={55}
                fontSize={13}
                className="border-none shadow-none bg-transparent"
              />
            </div>

            <div className="w-full pt-2 border-t border-[#1A1A1A] flex justify-between text-[10px] font-mono text-[#1A1A1A]/70 uppercase tracking-wider">
              <span>Stack: <strong className="text-[#1A1A1A]">{book.shelfLocation}</strong></span>
              <span>Class: <strong className="text-[#1A1A1A]">{book.category}</strong></span>
            </div>
          </div>
          <p className="text-[10px] font-sans uppercase tracking-widest text-[#1A1A1A]/50 mt-4">
            Certified for standard adhesive sleeve or bookplate printout
          </p>
        </div>

        {/* Action Buttons */}
        <div className="px-6 py-4 border-t border-[#1A1A1A] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-sans uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] font-semibold"
          >
            Close
          </button>
          <button
            id="print-barcode-btn"
            onClick={handlePrint}
            className="px-6 py-2.5 bg-[#1A1A1A] hover:bg-neutral-800 text-[#FDFCF8] border border-[#1A1A1A] text-xs font-sans uppercase font-bold tracking-widest flex items-center gap-2 transition-colors shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Label
          </button>
        </div>
      </div>
    </div>
  );
};
