import { SystemSettings, LoanTransaction, Book, Member } from '../types';

export function calculateOverdueDays(dueDateStr: string, returnDateStr?: string): number {
  const targetDate = returnDateStr ? new Date(returnDateStr) : new Date();
  const dueDate = new Date(dueDateStr);
  
  // Set hours to 0 to compare calendar days
  targetDate.setHours(0, 0, 0, 0);
  dueDate.setHours(0, 0, 0, 0);

  const diffTime = targetDate.getTime() - dueDate.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

export function computeLateFee(
  dueDateStr: string,
  settings: SystemSettings,
  returnDateStr?: string
): { overdueDays: number; chargeableDays: number; fee: number } {
  const overdueDays = calculateOverdueDays(dueDateStr, returnDateStr);
  const chargeableDays = Math.max(0, overdueDays - settings.gracePeriodDays);
  const fee = Number((chargeableDays * settings.dailyLateFeeRate).toFixed(2));
  return { overdueDays, chargeableDays, fee };
}

export function formatCurrency(amount: number, symbol = '$'): string {
  return `${symbol}${amount.toFixed(2)}`;
}

export function generateSqlDump(
  books: Book[],
  members: Member[],
  loans: LoanTransaction[],
  settings: SystemSettings
): string {
  const now = new Date().toISOString();
  let sql = `-- ============================================================
-- LIBRARY MANAGEMENT SYSTEM - SQL SCHEMA & DATA DUMP
-- Compatible with: SQLite 3 / MySQL 8.0 / PostgreSQL
-- Generated on: ${now}
-- Library: ${settings.libraryName}
-- ============================================================

-- 1. BOOKS INVENTORY TABLE
CREATE TABLE IF NOT EXISTS books (
  id VARCHAR(36) PRIMARY KEY,
  isbn VARCHAR(32) NOT NULL UNIQUE,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  publish_year INT NOT NULL,
  shelf_location VARCHAR(100) NOT NULL,
  total_copies INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  description TEXT,
  publisher VARCHAR(255),
  cover_color VARCHAR(16),
  added_date DATE NOT NULL
);

-- 2. PATRONS / MEMBERS TABLE
CREATE TABLE IF NOT EXISTS members (
  id VARCHAR(36) PRIMARY KEY,
  member_code VARCHAR(32) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(32) NOT NULL,
  role VARCHAR(32) NOT NULL DEFAULT 'Student',
  status VARCHAR(32) NOT NULL DEFAULT 'Active',
  joined_date DATE NOT NULL,
  max_borrow_limit INT NOT NULL DEFAULT 4,
  current_borrowed_count INT NOT NULL DEFAULT 0,
  unpaid_fines DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  department_or_program VARCHAR(150)
);

-- 3. LOAN TRANSACTIONS (ISSUE / RETURN)
CREATE TABLE IF NOT EXISTS loan_transactions (
  id VARCHAR(36) PRIMARY KEY,
  book_id VARCHAR(36) NOT NULL,
  member_id VARCHAR(36) NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE,
  status VARCHAR(32) NOT NULL DEFAULT 'Active',
  renewal_count INT NOT NULL DEFAULT 0,
  max_renewals INT NOT NULL DEFAULT 2,
  late_fee DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  late_fee_paid BOOLEAN NOT NULL DEFAULT FALSE,
  notes TEXT,
  reminders_sent_count INT NOT NULL DEFAULT 0,
  last_reminder_date DATE,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- 4. SYSTEM SETTINGS
CREATE TABLE IF NOT EXISTS system_settings (
  setting_key VARCHAR(64) PRIMARY KEY,
  setting_value VARCHAR(255) NOT NULL
);

INSERT INTO system_settings (setting_key, setting_value) VALUES
  ('library_name', '${settings.libraryName.replace(/'/g, "''")}'),
  ('daily_late_fee_rate', '${settings.dailyLateFeeRate}'),
  ('grace_period_days', '${settings.gracePeriodDays}'),
  ('standard_loan_days', '${settings.standardLoanDays}'),
  ('max_renewals_allowed', '${settings.maxRenewalsAllowed}')
ON CONFLICT (setting_key) DO NOTHING;

-- ============================================================
-- INSERT SEED DATA
-- ============================================================
\n`;

  // Books
  sql += `-- BOOKS SEED DATA\n`;
  for (const b of books) {
    const desc = (b.description || '').replace(/'/g, "''");
    const title = b.title.replace(/'/g, "''");
    const author = b.author.replace(/'/g, "''");
    sql += `INSERT INTO books (id, isbn, title, author, category, publish_year, shelf_location, total_copies, available_copies, description, added_date) VALUES ('${b.id}', '${b.isbn}', '${title}', '${author}', '${b.category}', ${b.publishYear}, '${b.shelfLocation}', ${b.totalCopies}, ${b.availableCopies}, '${desc}', '${b.addedDate}');\n`;
  }

  // Members
  sql += `\n-- MEMBERS SEED DATA\n`;
  for (const m of members) {
    const name = m.name.replace(/'/g, "''");
    const dept = (m.departmentOrProgram || '').replace(/'/g, "''");
    sql += `INSERT INTO members (id, member_code, name, email, phone, role, status, joined_date, max_borrow_limit, current_borrowed_count, unpaid_fines, department_or_program) VALUES ('${m.id}', '${m.memberCode}', '${name}', '${m.email}', '${m.phone}', '${m.role}', '${m.status}', '${m.joinedDate}', ${m.maxBorrowLimit}, ${m.currentBorrowedCount}, ${m.unpaidFines}, '${dept}');\n`;
  }

  // Loans
  sql += `\n-- LOANS SEED DATA\n`;
  for (const l of loans) {
    const retDateVal = l.returnDate ? `'${l.returnDate}'` : `NULL`;
    const notesVal = l.notes ? `'${l.notes.replace(/'/g, "''")}'` : `NULL`;
    const remDateVal = l.lastReminderSentDate ? `'${l.lastReminderSentDate}'` : `NULL`;
    sql += `INSERT INTO loan_transactions (id, book_id, member_id, issue_date, due_date, return_date, status, renewal_count, max_renewals, late_fee, late_fee_paid, notes, reminders_sent_count, last_reminder_date) VALUES ('${l.id}', '${l.bookId}', '${l.memberId}', '${l.issueDate}', '${l.dueDate}', ${retDateVal}, '${l.status}', ${l.renewalCount}, ${l.maxRenewals}, ${l.lateFee}, ${l.lateFeePaid ? 1 : 0}, ${notesVal}, ${l.remindersSentCount}, ${remDateVal});\n`;
  }

  return sql;
}
