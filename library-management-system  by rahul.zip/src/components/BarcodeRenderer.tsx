import React, { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';

interface BarcodeRendererProps {
  value: string;
  format?: 'CODE128' | 'EAN13' | 'pharmacode';
  width?: number;
  height?: number;
  displayValue?: boolean;
  fontSize?: number;
  className?: string;
  id?: string;
}

export const BarcodeRenderer: React.FC<BarcodeRendererProps> = ({
  value,
  format = 'CODE128',
  width = 1.6,
  height = 48,
  displayValue = true,
  fontSize = 12,
  className = '',
  id,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current || !value) return;

    try {
      JsBarcode(svgRef.current, value, {
        format: format,
        width: width,
        height: height,
        displayValue: displayValue,
        fontSize: fontSize,
        font: 'monospace',
        textAlign: 'center',
        textPosition: 'bottom',
        textMargin: 3,
        background: '#ffffff',
        lineColor: '#0f172a',
        margin: 6,
      });
    } catch (err) {
      // Fallback to generic code128 if EAN13 checksum fails or contains letters
      try {
        if (svgRef.current) {
          JsBarcode(svgRef.current, value, {
            format: 'CODE128',
            width: width,
            height: height,
            displayValue: displayValue,
            fontSize: fontSize,
            font: 'monospace',
            background: '#ffffff',
            lineColor: '#0f172a',
            margin: 6,
          });
        }
      } catch (fallbackErr) {
        console.warn('Barcode generation failed for:', value, fallbackErr);
      }
    }
  }, [value, format, width, height, displayValue, fontSize]);

  return (
    <div id={id} className={`inline-flex flex-col items-center bg-white p-1 rounded border border-slate-200 shadow-xs ${className}`}>
      <svg ref={svgRef} className="max-w-full h-auto" />
    </div>
  );
};
